// Synthesizes a small, clean UI/motion-graphics SFX kit (16-bit mono WAV) into public/sfx/.
// No downloads, deterministic (seeded noise). Run: npm run sfx
import { writeFileSync, mkdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const SR = 44100;
const OUT = join(dirname(fileURLToPath(import.meta.url)), "..", "public", "sfx");
mkdirSync(OUT, { recursive: true });

// seeded PRNG so every run is identical
let seed = 1337;
const rnd = () => {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return seed / 0xffffffff;
};
const noise = () => rnd() * 2 - 1;
const secs = (s) => Math.round(s * SR);

// ---- tiny DSP helpers ----
const lowpass = (x, cutoffHz) => {
  const a = 1 - Math.exp((-2 * Math.PI * cutoffHz) / SR);
  const y = new Float32Array(x.length);
  let s = 0;
  for (let i = 0; i < x.length; i++) {
    s += a * (x[i] - s);
    y[i] = s;
  }
  return y;
};
const highpass = (x, cutoffHz) => {
  const lp = lowpass(x, cutoffHz);
  return x.map((v, i) => v - lp[i]);
};
// very small reverb: a few soft, low-passed echoes
const tinyReverb = (x, mix = 0.12) => {
  const taps = [
    [0.021, 0.5],
    [0.037, 0.36],
    [0.053, 0.24],
    [0.079, 0.14],
  ];
  const extra = secs(0.09);
  const y = new Float32Array(x.length + extra);
  y.set(x);
  for (const [d, g] of taps) {
    const off = secs(d);
    for (let i = 0; i < x.length; i++) y[i + off] += x[i] * g * mix;
  }
  return y;
};
const fadeEdges = (x, inS = 0.004, outS = 0.01) => {
  const a = secs(inS),
    b = secs(outS);
  for (let i = 0; i < a && i < x.length; i++) x[i] *= i / a;
  for (let i = 0; i < b && i < x.length; i++) x[x.length - 1 - i] *= i / b;
  return x;
};

// ---- the six sounds ----
function whoosh(dur, lo, hi, peakAt = 0.45) {
  // band-pass noise sweep with fade in/out
  const N = secs(dur);
  const raw = new Float32Array(N);
  for (let i = 0; i < N; i++) raw[i] = noise();
  const out = new Float32Array(N);
  let l1 = 0,
    l2 = 0;
  for (let i = 0; i < N; i++) {
    const t = i / N;
    const fc = lo + (hi - lo) * Math.pow(Math.sin(Math.PI * Math.min(1, t / (peakAt * 2))) , 1.2) * (t < peakAt ? 1 : 1 - (t - peakAt) * 0.5);
    const a = 1 - Math.exp((-2 * Math.PI * Math.max(80, fc)) / SR);
    const b = 1 - Math.exp((-2 * Math.PI * Math.max(40, fc * 0.35)) / SR);
    l1 += a * (raw[i] - l1);
    l2 += b * (raw[i] - l2);
    const band = l1 - l2;
    const env = Math.pow(Math.sin(Math.PI * Math.pow(t, 0.8)), 2);
    out[i] = band * env;
  }
  return tinyReverb(lowpass(fadeEdges(out, 0.02, 0.06), 6000), 0.1);
}

function pop() {
  const N = secs(0.16);
  const out = new Float32Array(N);
  let ph = 0;
  for (let i = 0; i < N; i++) {
    const t = i / N;
    const f = 160 + 520 * Math.exp(-t * 9); // fast downward pitch
    ph += (2 * Math.PI * f) / SR;
    const env = Math.min(1, i / secs(0.004)) * Math.exp(-t * 7);
    out[i] = (Math.sin(ph) + 0.18 * Math.sin(ph * 2)) * env;
  }
  return tinyReverb(lowpass(fadeEdges(out), 4200), 0.1);
}

function click() {
  const N = secs(0.1);
  const raw = new Float32Array(N);
  for (let i = 0; i < N; i++) raw[i] = noise() * Math.exp(-(i / N) * 32);
  const hp = highpass(raw, 1800);
  let ph = 0;
  for (let i = 0; i < N; i++) {
    ph += (2 * Math.PI * 2300) / SR;
    hp[i] += 0.25 * Math.sin(ph) * Math.exp(-(i / N) * 40);
  }
  return tinyReverb(lowpass(fadeEdges(hp, 0.001, 0.02), 6500), 0.08);
}

function chime() {
  // soft pluck/chime: fundamental + gentle inharmonic overtones, slow-ish decay
  const N = secs(0.55);
  const out = new Float32Array(N);
  const f0 = 659.25; // E5
  const partials = [
    [1, 1, 5.5],
    [2.0, 0.32, 8],
    [2.76, 0.16, 11],
    [4.07, 0.07, 15],
  ];
  for (let i = 0; i < N; i++) {
    const t = i / SR;
    let v = 0;
    for (const [m, g, d] of partials) v += g * Math.sin(2 * Math.PI * f0 * m * t) * Math.exp(-t * d);
    out[i] = v * Math.min(1, i / secs(0.006));
  }
  return tinyReverb(lowpass(fadeEdges(out, 0.002, 0.08), 5200), 0.16);
}

function thud() {
  // very soft low thump (restrained)
  const N = secs(0.34);
  const out = new Float32Array(N);
  let ph = 0;
  for (let i = 0; i < N; i++) {
    const t = i / N;
    const f = 52 + 70 * Math.exp(-t * 14);
    ph += (2 * Math.PI * f) / SR;
    const env = Math.min(1, i / secs(0.012)) * Math.exp(-t * 7.5);
    out[i] = Math.sin(ph) * env;
  }
  return tinyReverb(lowpass(fadeEdges(out, 0.004, 0.06), 600), 0.08);
}

// ---- level matching + export ----
const TARGET_RMS = 0.13;
const PEAK_CEIL = 0.89;

function wavBuffer(samples) {
  const n = samples.length;
  const buf = Buffer.alloc(44 + n * 2);
  buf.write("RIFF", 0);
  buf.writeUInt32LE(36 + n * 2, 4);
  buf.write("WAVE", 8);
  buf.write("fmt ", 12);
  buf.writeUInt32LE(16, 16);
  buf.writeUInt16LE(1, 20);
  buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24);
  buf.writeUInt32LE(SR * 2, 28);
  buf.writeUInt16LE(2, 32);
  buf.writeUInt16LE(16, 34);
  buf.write("data", 36);
  buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) buf.writeInt16LE(Math.round(Math.max(-1, Math.min(1, samples[i])) * 32767), 44 + i * 2);
  return buf;
}

const kit = {
  whoosh: whoosh(0.5, 900, 3800),
  swipe: whoosh(0.68, 700, 4600, 0.5),
  pop: pop(),
  click: click(),
  chime: chime(),
  thud: thud(),
};

for (const [name, raw] of Object.entries(kit)) {
  let peak = 0,
    sum = 0;
  for (const v of raw) {
    peak = Math.max(peak, Math.abs(v));
    sum += v * v;
  }
  const rms = Math.sqrt(sum / raw.length);
  let gain = TARGET_RMS / rms;
  if (peak * gain > PEAK_CEIL) gain = PEAK_CEIL / peak;
  const out = raw.map((v) => v * gain);
  writeFileSync(join(OUT, `${name}.wav`), wavBuffer(out));
  let p2 = 0,
    s2 = 0;
  for (const v of out) {
    p2 = Math.max(p2, Math.abs(v));
    s2 += v * v;
  }
  console.log(
    `${name.padEnd(7)} ${(out.length / SR).toFixed(2)}s  peak ${p2.toFixed(3)}  rms ${Math.sqrt(s2 / out.length).toFixed(3)}  clip ${p2 >= 0.999 ? "YES" : "no"}`
  );
}
