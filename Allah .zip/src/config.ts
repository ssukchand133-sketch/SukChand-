// Project-wide switches.
export const VOICEOVER = {
  // Plays public/voiceover.mp3 (if the file exists) as a preview aid.
  enabled: true,
  // Default OFF in renders, so the exported MP4 contains SFX only.
  includeInRender: false,
};
