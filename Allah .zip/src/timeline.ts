// All timing is computed from the SRT. Nothing is hand-placed.
import { SRT } from "./srt";
import { theme } from "./theme";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

export type Cue = { index: number; s: number; e: number; text: string };

const toMs = (t: string) => {
  const m = t.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) return 0;
  return ((+m[1] * 60 + +m[2]) * 60 + +m[3]) * 1000 + +m[4];
};

export const parseSrt = (raw: string, fps: number): Cue[] =>
  raw
    .replace(/\r/g, "")
    .trim()
    .split(/\n\s*\n/)
    .map((block, i) => {
      const lines = block.split("\n");
      const timeLine = lines.find((l) => l.includes("-->")) ?? "";
      const [a, b] = timeLine.split("-->");
      const text = lines
        .slice(lines.indexOf(timeLine) + 1)
        .join(" ")
        .replace(/\[[^\]]*\]/g, "")
        .replace(/\s+/g, " ")
        .trim();
      return {
        index: i,
        s: Math.round((toMs(a) / 1000) * fps),
        e: Math.round((toMs(b) / 1000) * fps),
        text,
      };
    });

export const CUES = parseSrt(SRT, FPS);
export const TOTAL_FRAMES = Math.ceil(Math.max(...CUES.map((c) => c.e)));

// Which cues each scene covers (scene edges land on cue edges).
export const SCENE_CUES: Array<[number, number]> = [
  [0, 0], // 0 Hook
  [1, 1], // 1 Ask your heart
  [2, 3], // 2 Busy world + three "I have time" cards
  [4, 4], // 3 No time for prayer?
  [5, 5], // 4 Endless busyness vs. finite life
  [6, 6], // 5 Return — five prayers
  [7, 7], // 6 Seek forgiveness
  [8, 8], // 7 Closing dua
];

export const LEAD = Math.round(theme.timing.leadSec * FPS); // 5 frames

export type Rel = { s: number; e: number; dur: number }; // frames relative to scene start
export type SceneDef = { index: number; from: number; duration: number; rel: Rel[] };

export const SCENES: SceneDef[] = SCENE_CUES.map(([a, b], i) => {
  const from = i === 0 ? 0 : Math.max(0, CUES[a].s - LEAD);
  const next = i === SCENE_CUES.length - 1 ? TOTAL_FRAMES : Math.max(0, CUES[SCENE_CUES[i + 1][0]].s - LEAD);
  const rel = CUES.slice(a, b + 1).map((c) => ({ s: c.s - from, e: c.e - from, dur: c.e - c.s }));
  return { index: i, from, duration: next - from, rel };
});

export const lerpN = (a: number, b: number, t: number) => a + (b - a) * t;
// Frame within a cue at fraction f (0..1), relative to the scene, minus lead.
export const at = (r: Rel, f: number, lead = LEAD) => Math.max(0, Math.round(r.s + r.dur * f) - lead);

// Bengali digits (only used for numbers that appear in the script)
export const bn = (n: number) => String(Math.round(n)).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[+d]);
