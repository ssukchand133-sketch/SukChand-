import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { at } from "../timeline";
import { Words, Reveal, Sfx, useEase } from "../components/Motion";
import { Clock } from "../components/Icons";
import type { SceneProps } from "./types";

export const S3_NoTime: React.FC<SceneProps> = ({ rel, duration }) => {
  const frame = useCurrentFrame();
  const c = rel[0];
  const q2 = at(c, 0.5);
  const draw = useEase(0, 28, theme.ease.inOut);
  const ticks = Math.min(12, Math.floor(Math.max(0, Math.min(1, (frame - 6) / 26)) * 12.99));
  const minuteDeg = interpolate(frame, [0, duration - 20], [-60, 640], { easing: theme.ease.out, extrapolateRight: "clamp" });
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 520 - 300, top: 540 - 300, filter: `drop-shadow(0 0 50px ${theme.colors.glowAccent})` }}>
        <Reveal delay={0} y={0} scaleFrom={0.8} blur={0} cfg={theme.spring.bouncy}>
          <Clock size={600} draw={draw} minuteDeg={minuteDeg} ticks={ticks} id="clk" />
        </Reveal>
      </div>
      <div style={{ position: "absolute", left: 940, top: 0, bottom: 0, width: 900, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "flex-start", gap: 6 }}>
        <Reveal delay={2} y={20} blur={6}>
          <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.fonts.weight.strong, fontSize: 56, lineHeight: theme.type.lineHeight, color: theme.colors.textDim }}>কিন্তু</div>
        </Reveal>
        <Words text="নামাজ পড়ার জন্য" size={120} align="left" maxWidth={900} delay={6} stagger={5} highlight={{ 0: theme.colors.primary }} glow={{ 0: true }} />
        <Words text="একটু সময় নেই?" size={120} align="left" maxWidth={900} delay={q2} stagger={5} />
      </div>
      <Sfx name="pop" at={2} />
      <Sfx name="pop" at={q2} vol={0.8} rate={1.06} />
    </AbsoluteFill>
  );
};
