import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { at } from "../timeline";
import { Words, Sfx, useEase } from "../components/Motion";
import { Crescent } from "../components/Icons";
import type { SceneProps } from "./types";

export const S0_Hook: React.FC<SceneProps> = ({ rel }) => {
  const frame = useCurrentFrame();
  const c = rel[0];
  const line2 = at(c, 0.45, 0);
  const draw = useEase(0, 44, theme.ease.inOut);
  const fill = useEase(12, 36);
  const size = 470;
  return (
    <AbsoluteFill>
      <div
        style={{
          position: "absolute",
          left: 960 - 0.3425 * size,
          top: 255 - 0.5 * size,
          transform: `scale(${1 + Math.sin(frame / 26) * 0.015})`,
          filter: `drop-shadow(0 0 60px ${theme.colors.glowAccent})`,
          opacity: 0.9,
        }}
      >
        <Crescent size={size} id="hook" draw={draw} fill={fill} rotate={-8 + Math.sin(frame / 70) * 4} />
      </div>
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "flex-start", flexDirection: "column", paddingTop: 455 }}>
        <Words text="তুমি কি আল্লাহকে" size={156} delay={2} stagger={5} highlight={{ 2: theme.colors.primary }} glow={{ 2: true }} />
        <Words text="ভুলে গেছো?" size={156} delay={line2} stagger={5} />
      </AbsoluteFill>
      <Sfx name="whoosh" at={0} />
      <Sfx name="thud" at={line2} />
    </AbsoluteFill>
  );
};
