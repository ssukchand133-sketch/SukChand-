import type { Rel } from "../timeline";
export type SceneProps = { rel: Rel[]; duration: number };
