import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme, withAlpha } from "../theme";
import { at } from "../timeline";
import { Words, Sfx, usePop, useEase, clamp01 } from "../components/Motion";
import { CheckMark } from "../components/Icons";
import type { SceneProps } from "./types";

const X0 = 300;
const GAP = 330;
const Y = 610;

const Node: React.FC<{ i: number; ringAt: number; litAt: number }> = ({ i, ringAt, litAt }) => {
  const ring = useEase(ringAt, 16, theme.ease.inOut);
  const lit = usePop(litAt, theme.spring.bouncy);
  const chk = useEase(litAt + 2, 12);
  const l = clamp01(lit);
  return (
    <div style={{ position: "absolute", left: X0 + i * GAP - 52, top: Y - 52, width: 104, height: 104 }}>
      <svg width={104} height={104} viewBox="0 0 104 104" style={{ position: "absolute", inset: 0 }}>
        <circle cx="52" cy="52" r="46" fill="none" stroke={theme.colors.borderStrong} strokeWidth={4} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - ring} transform="rotate(-90 52 52)" />
      </svg>
      <div
        style={{
          position: "absolute",
          inset: 6,
          borderRadius: "50%",
          background: `radial-gradient(circle at 35% 30%, ${withAlpha(theme.colors.accent, 0.95)}, ${theme.colors.accent})`,
          boxShadow: `0 0 ${50 * l}px ${theme.colors.glowAccent}`,
          opacity: l,
          transform: `scale(${0.4 + 0.6 * lit})`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <CheckMark size={56} draw={chk} color={theme.colors.bg} stroke={6} />
      </div>
    </div>
  );
};

export const S5_FiveTimes: React.FC<SceneProps> = ({ rel }) => {
  const frame = useCurrentFrame();
  const c = rel[0];
  const t0 = at(c, 0.46, 0);
  const t1 = at(c, 0.8, 0);
  const lit = [0, 1, 2, 3, 4].map((i) => Math.round(t0 + (i * (t1 - t0)) / 4));
  const lineIn = useEase(18, 30, theme.ease.inOut);
  const litLine = interpolate(frame, [lit[0], lit[4]], [0, 4 * GAP], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const labelAt = at(c, 0.4);
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", top: 170, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Words text="আল্লাহর পথে ফিরে এসো" size={124} delay={0} stagger={5} highlight={{ 2: theme.colors.primary, 3: theme.colors.primary }} glow={{ 2: true, 3: true }} />
      </div>
      <div style={{ position: "absolute", left: X0, top: Y - 3, width: 4 * GAP * lineIn, height: 6, borderRadius: 3, background: theme.colors.border }} />
      <div style={{ position: "absolute", left: X0, top: Y - 3, width: litLine, height: 6, borderRadius: 3, background: theme.colors.accent, boxShadow: `0 0 20px ${theme.colors.glowAccent}` }} />
      {[0, 1, 2, 3, 4].map((i) => (
        <Node key={i} i={i} ringAt={22 + i * 4} litAt={lit[i]} />
      ))}
      <div style={{ position: "absolute", top: 760, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Words text="পাঁচ ওয়াক্ত নামাজ" size={88} delay={labelAt} stagger={5} />
      </div>
      <Sfx name="whoosh" at={0} />
      <Sfx name="pop" at={labelAt} vol={0.8} />
      {lit.map((t, i) => (
        <Sfx key={i} name="click" at={t + 2} rate={1 + i * 0.035} />
      ))}
    </AbsoluteFill>
  );
};
