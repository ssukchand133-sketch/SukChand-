import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme, withAlpha } from "../theme";
import { at } from "../timeline";
import { Words, Sfx, usePop, clamp01 } from "../components/Motion";
import type { SceneProps } from "./types";

const Ray: React.FC<{ i: number }> = ({ i }) => {
  const frame = useCurrentFrame();
  const p = usePop(4 + i * 3, theme.spring.smooth);
  const angle = (i - 4) * 14 + Math.sin(frame / 80 + i) * 1.6;
  const breathe = 0.8 + 0.2 * Math.sin(frame / 22 + i * 1.3);
  return (
    <div
      style={{
        position: "absolute",
        left: 960 - 13,
        top: 1180 - 1500,
        width: 26,
        height: 1500,
        transformOrigin: "50% 100%",
        transform: `rotate(${angle}deg) scaleY(${clamp01(p)})`,
        background: `linear-gradient(0deg, ${withAlpha(theme.colors.accent, 0.3 * breathe)}, transparent)`,
        filter: "blur(2px)",
        borderRadius: 13,
      }}
    />
  );
};

export const S6_Forgive: React.FC<SceneProps> = ({ rel }) => {
  const c = rel[0];
  const subAt = at(c, 0.32);
  const lastAt = at(c, 0.74);
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 960 - 800, top: 1180 - 420, width: 1600, height: 840, background: `radial-gradient(ellipse at 50% 50%, ${withAlpha(theme.colors.primary, 0.16)}, transparent 65%)` }} />
      {Array.from({ length: 9 }).map((_, i) => (
        <Ray key={i} i={i} />
      ))}
      <div style={{ position: "absolute", top: 150, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Words text="ক্ষমা চাও" size={230} delay={6} stagger={6} highlight={{ 0: theme.colors.primary, 1: theme.colors.primary }} glow={{ 0: true, 1: true }} />
      </div>
      <div style={{ position: "absolute", top: 560, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Words text="দুনিয়ার পেছনে ছুটতে ছুটতে" size={64} color={theme.colors.textDim} delay={subAt} stagger={4} />
      </div>
      <div style={{ position: "absolute", top: 690, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Words text="আমাদের রবকে…" size={108} delay={lastAt} stagger={5} />
      </div>
      <Sfx name="chime" at={6} />
      <Sfx name="pop" at={subAt} vol={0.7} />
      <Sfx name="pop" at={lastAt} vol={0.8} rate={1.05} />
    </AbsoluteFill>
  );
};
