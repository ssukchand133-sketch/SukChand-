import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { at } from "../timeline";
import { Words, Reveal, Sfx } from "../components/Motion";
import { InfinityMark, Hourglass } from "../components/Icons";
import type { SceneProps } from "./types";

const Panel: React.FC<{ left: number; children: React.ReactNode }> = ({ left, children }) => (
  <div
    style={{
      position: "absolute",
      left,
      top: 210,
      width: 840,
      height: 700,
      boxSizing: "border-box",
      borderRadius: theme.radius.card,
      background: `linear-gradient(160deg, ${theme.colors.surfaceStrong}, ${theme.colors.surface})`,
      border: `1.5px solid ${theme.colors.border}`,
      boxShadow: theme.shadow.card,
      backdropFilter: "blur(14px)",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      gap: 10,
    }}
  >
    {children}
  </div>
);

export const S4_BeforeAfter: React.FC<SceneProps> = ({ rel, duration }) => {
  const frame = useCurrentFrame();
  const c = rel[0];
  const rStart = at(c, 0.5);
  const progress = interpolate(frame, [rStart + 14, duration - 22], [0, 0.95], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const drawH = interpolate(frame, [rStart, rStart + 24], [0, 1], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", top: 70, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Reveal delay={0} y={20} blur={6}>
          <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.fonts.weight.display, fontSize: 64, lineHeight: theme.type.lineHeight, color: theme.colors.accent }}>মনে রেখো</div>
        </Reveal>
      </div>

      <Reveal delay={2} x={-70} y={0} blur={8} style={{ position: "absolute", inset: 0 }}>
        <Panel left={110}>
          <div style={{ marginBottom: 20 }}>
            <InfinityMark width={560} t={(frame * 0.012) % 1} />
          </div>
          <Words text="দুনিয়ার ব্যস্ততা" size={60} color={theme.colors.textDim} delay={10} stagger={4} />
          <Words text="কখনো শেষ হবে না" size={74} delay={16} stagger={4} />
        </Panel>
      </Reveal>

      <Reveal delay={rStart} x={70} y={0} blur={8} style={{ position: "absolute", inset: 0 }}>
        <Panel left={970}>
          <div style={{ marginBottom: 8, filter: `drop-shadow(0 0 30px ${theme.colors.glow})` }}>
            <Hourglass height={340} progress={progress} id="hg" draw={drawH} />
          </div>
          <Words text="তোমার জীবন" size={60} color={theme.colors.textDim} delay={rStart + 8} stagger={4} />
          <Words text="একদিন শেষ হয়ে যাবে" size={70} delay={rStart + 14} stagger={4} />
        </Panel>
      </Reveal>

      <Reveal delay={rStart - 2} y={0} scaleFrom={0.7} blur={0} cfg={theme.spring.bouncy} style={{ position: "absolute", left: 960 - 90, top: 540 - 40, width: 180 }}>
        <div style={{ textAlign: "center", fontFamily: theme.fonts.display, fontWeight: theme.fonts.weight.strong, fontSize: 40, lineHeight: theme.type.lineHeight, color: theme.colors.text, background: theme.colors.bg, border: `1.5px solid ${theme.colors.borderStrong}`, borderRadius: theme.radius.pill, padding: "2px 0 6px" }}>কিন্তু</div>
      </Reveal>

      <Sfx name="pop" at={4} />
      <Sfx name="pop" at={rStart + 2} rate={0.94} />
      <Sfx name="thud" at={rStart + 2} vol={0.7} />
    </AbsoluteFill>
  );
};
