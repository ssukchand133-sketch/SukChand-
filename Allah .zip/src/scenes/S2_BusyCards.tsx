import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme, withAlpha } from "../theme";
import { LEAD } from "../timeline";
import { Words, Reveal, Sfx, usePop, useEase, clamp01 } from "../components/Motion";
import { PhoneIcon, ChatIcon, CoinIcon, CheckMark } from "../components/Icons";
import type { SceneProps } from "./types";

const CARDS = [
  { label: "মোবাইল দেখা", Icon: PhoneIcon, rotY: 9 },
  { label: "মানুষের সঙ্গে কথা", Icon: ChatIcon, rotY: 0 },
  { label: "টাকা উপার্জন", Icon: CoinIcon, rotY: -9 },
] as const;

const Orbit: React.FC<{ exitAt: number }> = ({ exitAt }) => {
  const frame = useCurrentFrame();
  const enter = useEase(10, 24);
  const exit = interpolate(frame, [exitAt, exitAt + 14], [0, 1], { easing: theme.ease.in, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const rings = [
    { r: 120, n: 2, sp: 2.4, d: 12 },
    { r: 200, n: 3, sp: -1.6, d: 15 },
    { r: 280, n: 4, sp: 1.1, d: 18 },
  ];
  return (
    <div style={{ position: "absolute", left: 960, top: 690, width: 0, height: 0, opacity: enter * (1 - exit), transform: `scale(${(0.85 + 0.15 * enter) * (1 - 0.35 * exit)})` }}>
      {rings.map((ring, i) => (
        <React.Fragment key={i}>
          <div style={{ position: "absolute", left: -ring.r, top: -ring.r, width: ring.r * 2, height: ring.r * 2, borderRadius: "50%", border: `2px solid ${theme.colors.border}` }} />
          {Array.from({ length: ring.n }).map((_, j) => {
            const a = ((frame * ring.sp + (360 / ring.n) * j + i * 40) * Math.PI) / 180;
            return (
              <div
                key={j}
                style={{
                  position: "absolute",
                  left: Math.cos(a) * ring.r - ring.d,
                  top: Math.sin(a) * ring.r - ring.d,
                  width: ring.d * 2,
                  height: ring.d * 2,
                  borderRadius: "50%",
                  background: i === 1 ? theme.colors.text : theme.colors.accent,
                  boxShadow: `0 0 24px ${theme.colors.glowAccent}`,
                }}
              />
            );
          })}
        </React.Fragment>
      ))}
      <div style={{ position: "absolute", left: -48, top: -48, width: 96, height: 96, borderRadius: "50%", background: `radial-gradient(circle at 35% 30%, ${theme.colors.text}, ${theme.colors.accent} 75%)`, boxShadow: `0 0 60px ${theme.colors.glowAccent}`, transform: `scale(${1 + Math.sin(frame / 14) * 0.05})` }} />
    </div>
  );
};

const GlassCard: React.FC<{ k: number; t: number; nextT: number | null }> = ({ k, t, nextT }) => {
  const frame = useCurrentFrame();
  const { label, Icon, rotY } = CARDS[k];
  const p = usePop(t, theme.spring.smooth);
  const draw = useEase(t + 4, 24, theme.ease.inOut);
  const chk = useEase(t + 18, 12);
  const dim = nextT === null ? 1 : interpolate(frame, [nextT, nextT + 14], [1, 0.74], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const lift = nextT === null ? 1 : 1 - 0.04 * (1 - dim) / 0.26;
  return (
    <div style={{ width: 480, height: 540, perspective: 1600 }}>
      <div
        style={{
          width: "100%",
          height: "100%",
          boxSizing: "border-box",
          borderRadius: theme.radius.card,
          background: `linear-gradient(160deg, ${theme.colors.surfaceStrong}, ${theme.colors.surface})`,
          border: `1.5px solid ${theme.colors.border}`,
          boxShadow: theme.shadow.card,
          backdropFilter: "blur(14px)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: 22,
          opacity: clamp01(p * 1.5) * dim,
          transform: `translateY(${(1 - p) * 90 + Math.sin(frame / 30 + k) * 5}px) rotateX(${(1 - p) * 14}deg) rotateY(${rotY * (0.4 + 0.6 * p)}deg) scale(${(0.9 + 0.1 * p) * lift})`,
        }}
      >
        <Icon size={190} draw={draw} />
        <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.fonts.weight.display, fontSize: 56, lineHeight: theme.type.lineHeight, color: theme.colors.text, textAlign: "center", padding: "0 20px" }}>{label}</div>
        <div style={{ display: "flex", alignItems: "center", gap: 12, opacity: chk, transform: `translateY(${(1 - chk) * 10}px)`, background: withAlpha(theme.colors.accent, 0.14), border: `1.5px solid ${withAlpha(theme.colors.accent, 0.5)}`, borderRadius: theme.radius.pill, padding: "2px 26px 4px 16px" }}>
          <CheckMark size={38} draw={chk} />
          <span style={{ fontFamily: theme.fonts.display, fontWeight: theme.fonts.weight.strong, fontSize: 44, lineHeight: theme.type.lineHeight, color: theme.colors.accent }}>সময় আছে</span>
        </div>
      </div>
    </div>
  );
};

export const S2_BusyCards: React.FC<SceneProps> = ({ rel }) => {
  const cardCue = rel[1];
  const step = cardCue.dur / 3; // equal spacing across the cue
  const ts = [0, 1, 2].map((k) => Math.max(0, Math.round(cardCue.s + k * step) - LEAD));
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", top: 90, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Words text="সারাদিন দুনিয়ার কাজ নিয়ে ব্যস্ত" size={108} maxWidth={1640} delay={0} stagger={4} highlight={{ 4: theme.colors.primary }} glow={{ 4: true }} />
      </div>
      <Orbit exitAt={ts[0] - 6} />
      <div style={{ position: "absolute", left: 0, right: 0, top: 360, display: "flex", justifyContent: "center", gap: 56 }}>
        {[0, 1, 2].map((k) => (
          <GlassCard key={k} k={k} t={ts[k]} nextT={k < 2 ? ts[k + 1] : null} />
        ))}
      </div>
      <Sfx name="whoosh" at={0} />
      {ts.map((t, k) => (
        <React.Fragment key={k}>
          <Sfx name="pop" at={t + 2} rate={[0.96, 1, 1.05][k]} />
          <Sfx name="click" at={t + 18} rate={[1, 1.04, 1.08][k]} />
        </React.Fragment>
      ))}
    </AbsoluteFill>
  );
};
