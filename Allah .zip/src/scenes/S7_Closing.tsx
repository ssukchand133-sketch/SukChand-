import React from "react";
import { AbsoluteFill, interpolate, interpolateColors, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { at } from "../timeline";
import { Words, Sfx, useEase } from "../components/Motion";
import { Crescent } from "../components/Icons";
import type { SceneProps } from "./types";

export const S7_Closing: React.FC<SceneProps> = ({ rel }) => {
  const frame = useCurrentFrame();
  const c = rel[0];
  const pB = at(c, 0.28);
  const pC = at(c, 0.88);
  const draw = useEase(0, 40, theme.ease.inOut);
  const fill = useEase(10, 40);
  const lineA = interpolate(frame, [pB - 12, pB - 2], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const moveB = useEase(pC, 16, theme.ease.inOut);
  const goldToText = interpolateColors(frame, [pC, pC + 14], [theme.colors.primary, theme.colors.text]);
  const size = 300;
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 960 - 0.3425 * size, top: 220 - 0.5 * size, filter: `drop-shadow(0 0 40px ${theme.colors.glowAccent})`, transform: `scale(${1 + Math.sin(frame / 30) * 0.02})` }}>
        <Crescent size={size} id="end" draw={draw} fill={fill} rotate={-8 + Math.sin(frame / 60) * 3} />
      </div>

      <div style={{ position: "absolute", top: 500, left: 0, right: 0, display: "flex", justifyContent: "center", opacity: lineA }}>
        <Words text="ভুলে না যাই" size={78} color={theme.colors.textDim} delay={3} stagger={5} />
      </div>

      <div style={{ position: "absolute", top: 460 - 40 * moveB, left: 0, right: 0, display: "flex", justifyContent: "center", opacity: frame >= pB - 2 ? 1 : 0 }}>
        <Words text="সঠিক পথে চলার তৌফিক" size={108} delay={pB} stagger={5} highlight={{ 0: goldToText, 1: goldToText }} glow={{ 0: frame < pC + 14, 1: frame < pC + 14 }} />
      </div>

      <div style={{ position: "absolute", top: 640, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Words text="আমিন" size={230} delay={pC} stagger={5} highlight={{ 0: theme.colors.primary }} glow={{ 0: true }} cfg={theme.spring.bouncy} />
      </div>

      <Sfx name="chime" at={pB} />
      <Sfx name="chime" at={pC} rate={0.94} vol={0.9} />
      <Sfx name="thud" at={pC} vol={0.7} />
    </AbsoluteFill>
  );
};
