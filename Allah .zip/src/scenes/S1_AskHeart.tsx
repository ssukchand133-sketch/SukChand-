import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme, withAlpha } from "../theme";
import { at } from "../timeline";
import { Words, Reveal, Sfx, useEase } from "../components/Motion";
import type { SceneProps } from "./types";

const RING = 76;
export const S1_AskHeart: React.FC<SceneProps> = ({ rel }) => {
  const frame = useCurrentFrame();
  const c = rel[0];
  const sub = at(c, 0.5);
  const enter = useEase(0, 22);
  const beat = Math.pow(Math.max(0, Math.sin(frame / 5.2)), 6); // heartbeat-like pulse
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 480, top: 540, width: 0, height: 0 }}>
        {[0, 1, 2, 3].map((k) => {
          const ph = (((frame - k * 19) % RING) + RING) % RING / RING;
          const r = 60 + ph * 330;
          return (
            <div
              key={k}
              style={{
                position: "absolute",
                left: -r,
                top: -r,
                width: r * 2,
                height: r * 2,
                borderRadius: "50%",
                border: `3px solid ${withAlpha(theme.colors.accent, (1 - ph) * 0.6 * enter)}`,
              }}
            />
          );
        })}
        <div
          style={{
            position: "absolute",
            left: -62,
            top: -62,
            width: 124,
            height: 124,
            borderRadius: "50%",
            transform: `scale(${(0.6 + 0.4 * enter) * (1 + beat * 0.16)})`,
            background: `radial-gradient(circle at 35% 30%, ${theme.colors.text}, ${theme.colors.accent} 70%)`,
            boxShadow: `0 0 70px ${theme.colors.glowAccent}`,
            opacity: enter,
          }}
        />
      </div>

      <div style={{ position: "absolute", left: 960, top: 0, bottom: 0, width: 860, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "flex-start", gap: 18 }}>
        <Reveal delay={0} y={24} blur={6}>
          <div
            style={{
              fontFamily: theme.fonts.display,
              fontWeight: theme.fonts.weight.strong,
              fontSize: 54,
              lineHeight: theme.type.lineHeight,
              color: theme.colors.accent,
              border: `2px solid ${theme.colors.accent}`,
              borderRadius: theme.radius.pill,
              padding: "2px 34px 6px",
            }}
          >
            একবার
          </div>
        </Reveal>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start" }}>
          <Words text="নিজের মনকে" size={132} align="left" delay={4} stagger={5} highlight={{ 1: theme.colors.primary }} glow={{ 1: true }} />
          <Words text="প্রশ্ন করো" size={132} align="left" delay={14} stagger={5} />
        </div>
        <Words text="তুমি কি সত্যিই আল্লাহকে ভুলে গেছো?" size={58} align="left" maxWidth={820} color={theme.colors.textDim} delay={sub} stagger={3} highlight={{ 2: theme.colors.accent }} />
      </div>
      <Sfx name="pop" at={2} />
      <Sfx name="pop" at={sub} vol={0.8} rate={0.96} />
    </AbsoluteFill>
  );
};
