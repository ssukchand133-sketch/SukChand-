import React from "react";
import { Audio, getRemotionEnvironment, getStaticFiles, staticFile } from "remotion";
import { VOICEOVER } from "../config";

/** Plays public/voiceover.mp3 if (and only if) the file exists. Silent no-op otherwise. */
export const PreviewAudio: React.FC = () => {
  if (!VOICEOVER.enabled) return null;
  const env = getRemotionEnvironment();
  if (env.isRendering && !VOICEOVER.includeInRender) return null;
  let exists = false;
  try {
    exists = getStaticFiles().some((f) => f.name === "voiceover.mp3");
  } catch {
    exists = false;
  }
  return exists ? <Audio src={staticFile("voiceover.mp3")} volume={1} /> : null;
};
