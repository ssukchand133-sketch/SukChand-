import React from "react";
import { Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

export type SpringCfg = { damping: number; stiffness: number; mass: number };

/** 0→1 spring progress starting at `delay` frames (scene-relative). */
export const usePop = (delay = 0, cfg: SpringCfg = theme.spring.snappy) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config: cfg });
};

export const clamp01 = (n: number) => Math.max(0, Math.min(1, n));

/** Eased 0→1 over [start, start+len]. */
export const useEase = (start: number, len: number, ease: (t: number) => number = theme.ease.out) => {
  const frame = useCurrentFrame();
  return interpolate(frame, [start, start + len], [0, 1], {
    easing: ease,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
};

/** Fade/slide a block in. */
export const Reveal: React.FC<{
  delay?: number;
  y?: number;
  x?: number;
  scaleFrom?: number;
  blur?: number;
  cfg?: SpringCfg;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({ delay = 0, y = 40, x = 0, scaleFrom = 0.94, blur = 10, cfg = theme.spring.smooth, style, children }) => {
  const p = usePop(delay, cfg);
  return (
    <div
      style={{
        opacity: clamp01(p * 1.6),
        transform: `translate(${(1 - p) * x}px, ${(1 - p) * y}px) scale(${scaleFrom + (1 - scaleFrom) * p})`,
        filter: blur ? `blur(${(1 - clamp01(p)) * blur}px)` : undefined,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

const GLOW_PX = 42;

const Word: React.FC<{ delay: number; cfg: SpringCfg; color: string; glow: boolean; children: React.ReactNode }> = ({
  delay,
  cfg,
  color,
  glow,
  children,
}) => {
  const p = usePop(delay, cfg);
  return (
    <span
      style={{
        display: "inline-block",
        color,
        opacity: clamp01(p * 1.8),
        transform: `translateY(${(1 - p) * 46}px) scale(${0.9 + 0.1 * p})`,
        filter: `blur(${(1 - clamp01(p)) * 12}px)`,
        textShadow: glow ? `0 0 ${GLOW_PX}px ${theme.colors.glow}` : undefined,
        whiteSpace: "nowrap",
      }}
    >
      {children}
    </span>
  );
};

/** Word-by-word staggered text. Splits on SPACES only (never characters) — safe for Bengali. */
export const Words: React.FC<{
  text: string;
  delay?: number;
  stagger?: number;
  size: number;
  color?: string;
  weight?: number;
  highlight?: Record<number, string>;
  glow?: Record<number, boolean>;
  align?: "center" | "left";
  maxWidth?: number;
  gap?: number;
  cfg?: SpringCfg;
}> = ({
  text,
  delay = 0,
  stagger = 4,
  size,
  color = theme.colors.text,
  weight = theme.fonts.weight.display,
  highlight = {},
  glow = {},
  align = "center",
  maxWidth,
  gap = 0.28,
  cfg = theme.spring.snappy,
}) => {
  const words = text.split(" ");
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: align === "center" ? "center" : "flex-start",
        columnGap: size * gap,
        maxWidth,
        fontFamily: theme.fonts.display,
        fontWeight: weight,
        fontSize: size,
        lineHeight: theme.type.lineHeight,
        letterSpacing: theme.type.letterSpacing,
        color,
      }}
    >
      {words.map((w, i) => (
        <Word key={i} delay={delay + i * stagger} cfg={cfg} color={highlight[i] ?? color} glow={!!glow[i]}>
          {w}
        </Word>
      ))}
    </div>
  );
};

/** SFX placed at a scene-relative frame. */
export const Sfx: React.FC<{ name: keyof typeof theme.sfx; at: number; vol?: number; rate?: number }> = ({
  name,
  at,
  vol = 1,
  rate = 1,
}) => (
  <Sequence from={Math.max(0, Math.round(at))} layout="none">
    <Audio src={staticFile(`sfx/${name}.wav`)} volume={theme.sfx[name] * vol} playbackRate={rate} />
  </Sequence>
);

/** Per-scene wrapper: soft entrance + faster exit. */
export const SceneShell: React.FC<{ duration: number; first?: boolean; children: React.ReactNode }> = ({
  duration,
  first,
  children,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const inLen = Math.round(theme.timing.sceneInSec * fps);
  const outLen = Math.round(theme.timing.sceneOutSec * fps);
  const pin = first ? 1 : interpolate(frame, [0, inLen], [0, 1], { easing: theme.ease.out, extrapolateRight: "clamp" });
  const pout = interpolate(frame, [duration - outLen, duration - 1], [0, 1], {
    easing: theme.ease.in,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const scale = (first ? 1 : 1.035 - 0.035 * pin) * (1 - 0.03 * pout);
  const blur = (first ? 0 : (1 - pin) * 8) + pout * 7;
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        opacity: (first ? 1 : pin) * (1 - pout),
        transform: `scale(${scale})`,
        filter: blur > 0.2 ? `blur(${blur}px)` : undefined,
      }}
    >
      {children}
    </div>
  );
};
