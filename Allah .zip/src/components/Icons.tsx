import React from "react";
import { theme } from "../theme";

type P = { size?: number; color?: string; draw?: number; stroke?: number };
const dash = (draw: number) => ({ pathLength: 1, strokeDasharray: 1, strokeDashoffset: 1 - draw });

export const Crescent: React.FC<{ size: number; id: string; draw?: number; fill?: number; color?: string; rotate?: number }> = ({
  size,
  id,
  draw = 1,
  fill = 1,
  color = theme.colors.accent,
  rotate = 0,
}) => (
  <svg width={size} height={size} viewBox="0 0 400 400" style={{ transform: `rotate(${rotate}deg)`, overflow: "visible" }}>
    <defs>
      <linearGradient id={`${id}-g`} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor={color} stopOpacity={0.34} />
        <stop offset="1" stopColor={color} stopOpacity={0.06} />
      </linearGradient>
    </defs>
    <path d="M250 70 A150 150 0 1 0 250 330 A140 140 0 0 1 250 70 Z" fill={`url(#${id}-g)`} opacity={fill} />
    <path
      d="M250 70 A150 150 0 1 0 250 330 A140 140 0 0 1 250 70 Z"
      fill="none"
      stroke={color}
      strokeWidth={4}
      strokeLinejoin="round"
      strokeLinecap="round"
      {...dash(draw)}
    />
  </svg>
);

export const PhoneIcon: React.FC<P> = ({ size = 150, color = theme.colors.accent, draw = 1, stroke = 5 }) => (
  <svg width={size} height={size} viewBox="0 0 120 120" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <rect x="34" y="12" width="52" height="96" rx="12" {...dash(draw)} />
    <path d="M52 22 H68" {...dash(draw)} />
    <rect x="44" y="36" width="32" height="20" rx="5" opacity={draw} />
    <path d="M44 68 H76 M44 80 H66" opacity={draw} />
  </svg>
);

export const ChatIcon: React.FC<P> = ({ size = 150, color = theme.colors.accent, draw = 1, stroke = 5 }) => (
  <svg width={size} height={size} viewBox="0 0 120 120" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 26 Q14 14 26 14 H66 Q78 14 78 26 V52 Q78 64 66 64 H40 L24 78 V64 H26 Q14 64 14 52 Z" {...dash(draw)} />
    <path d="M60 78 H82 L96 92 V78 H98 Q108 78 108 68 V46" opacity={draw} />
    <path d="M30 34 H62 M30 46 H50" opacity={draw} />
  </svg>
);

export const CoinIcon: React.FC<P> = ({ size = 150, color = theme.colors.accent, draw = 1, stroke = 5 }) => (
  <svg width={size} height={size} viewBox="0 0 120 120" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <circle cx="60" cy="60" r="44" {...dash(draw)} />
    <circle cx="60" cy="60" r="30" opacity={draw * 0.7} />
    <path d="M60 40 V80 M50 50 Q60 42 70 50 M50 70 Q60 78 70 70" opacity={draw} />
  </svg>
);

export const CheckMark: React.FC<{ size: number; draw: number; color?: string; stroke?: number }> = ({
  size,
  draw,
  color = theme.colors.accent,
  stroke = 7,
}) => (
  <svg width={size} height={size} viewBox="0 0 40 40" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 21 L17 29 L31 12" {...dash(draw)} />
  </svg>
);

export const InfinityMark: React.FC<{ width: number; t: number; color?: string }> = ({ width, t, color = theme.colors.accent }) => {
  const d = "M200 100 C140 20 40 20 40 100 C40 180 140 180 200 100 C260 20 360 20 360 100 C360 180 260 180 200 100 Z";
  return (
    <svg width={width} height={width / 2} viewBox="0 0 400 200" fill="none" strokeLinecap="round" style={{ overflow: "visible" }}>
      <path d={d} stroke={color} strokeOpacity={0.22} strokeWidth={8} />
      <path
        d={d}
        stroke={color}
        strokeWidth={10}
        pathLength={1}
        strokeDasharray="0.22 0.78"
        strokeDashoffset={-t}
        style={{ filter: `drop-shadow(0 0 14px ${theme.colors.glowAccent})` }}
      />
    </svg>
  );
};

export const HOURGLASS =
  "M30 20 H170 C170 90 112 130 104 150 C112 170 170 210 170 280 H30 C30 210 88 170 96 150 C88 130 30 90 30 20 Z";
export const Hourglass: React.FC<{ height: number; progress: number; id: string; draw?: number }> = ({ height, progress, id, draw = 1 }) => {
  const topY = 20 + 130 * progress;
  const botH = 128 * progress;
  return (
    <svg width={height * (200 / 300)} height={height} viewBox="0 0 200 300" fill="none" style={{ overflow: "visible" }}>
      <defs>
        <clipPath id={`${id}-c`}>
          <path d={HOURGLASS} />
        </clipPath>
        <linearGradient id={`${id}-s`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={theme.colors.primary} />
          <stop offset="1" stopColor={theme.colors.primary} stopOpacity={0.7} />
        </linearGradient>
      </defs>
      <g clipPath={`url(#${id}-c)`}>
        <rect x="20" y={topY} width="160" height={Math.max(0, 150 - topY)} fill={`url(#${id}-s)`} />
        <rect x="20" y={280 - botH} width="160" height={botH} fill={`url(#${id}-s)`} />
      </g>
      {progress > 0.01 && progress < 0.985 && (
        <line x1="100" y1="148" x2="100" y2={280 - botH} stroke={theme.colors.primary} strokeWidth={3} strokeLinecap="round" />
      )}
      <path d={HOURGLASS} stroke={theme.colors.text} strokeOpacity={0.85} strokeWidth={5} strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - draw} />
      <path d="M22 14 H178 M22 286 H178" stroke={theme.colors.text} strokeOpacity={0.85} strokeWidth={8} strokeLinecap="round" opacity={draw} />
    </svg>
  );
};

export const Clock: React.FC<{ size: number; draw: number; minuteDeg: number; ticks: number; id: string }> = ({
  size,
  draw,
  minuteDeg,
  ticks,
  id,
}) => {
  const hourDeg = minuteDeg / 12 + 300;
  return (
    <svg width={size} height={size} viewBox="0 0 300 300" fill="none" style={{ overflow: "visible" }}>
      <defs>
        <radialGradient id={`${id}-f`}>
          <stop offset="0" stopColor={theme.colors.accent} stopOpacity={0.14} />
          <stop offset="1" stopColor={theme.colors.accent} stopOpacity={0.03} />
        </radialGradient>
      </defs>
      <circle cx="150" cy="150" r="136" fill={`url(#${id}-f)`} opacity={draw} />
      <circle cx="150" cy="150" r="136" stroke={theme.colors.accent} strokeWidth={5} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - draw} transform="rotate(-90 150 150)" />
      {Array.from({ length: 12 }).map((_, i) => (
        <line
          key={i}
          x1="150"
          y1={i % 3 === 0 ? 28 : 34}
          x2="150"
          y2="44"
          stroke={theme.colors.text}
          strokeWidth={i % 3 === 0 ? 6 : 3.5}
          strokeLinecap="round"
          opacity={ticks > i ? 0.8 : 0}
          transform={`rotate(${i * 30} 150 150)`}
        />
      ))}
      <line x1="150" y1="150" x2="150" y2="82" stroke={theme.colors.text} strokeWidth={8} strokeLinecap="round" transform={`rotate(${hourDeg} 150 150)`} opacity={draw} />
      <line x1="150" y1="150" x2="150" y2="48" stroke={theme.colors.text} strokeWidth={5} strokeLinecap="round" transform={`rotate(${minuteDeg} 150 150)`} opacity={draw} />
      <circle cx="150" cy="150" r="9" fill={theme.colors.text} opacity={draw} />
    </svg>
  );
};
