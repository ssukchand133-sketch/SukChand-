import React from "react";
import { AbsoluteFill, interpolate, random, useCurrentFrame, useVideoConfig } from "remotion";
import { theme, withAlpha } from "../theme";
import { SCENES, WIDTH, HEIGHT } from "../timeline";

// Slowly migrating glow centers, one per scene (percent of frame).
const GLOW: Array<[number, number]> = [
  [50, 38],
  [30, 50],
  [50, 30],
  [28, 52],
  [50, 55],
  [50, 62],
  [50, 100],
  [50, 34],
];

export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  let idx = 0;
  for (let i = 0; i < SCENES.length; i++) if (frame >= SCENES[i].from) idx = i;
  const prev = GLOW[Math.max(0, idx - 1)];
  const cur = GLOW[idx];
  const t =
    idx === 0
      ? 1
      : interpolate(frame, [SCENES[idx].from, SCENES[idx].from + 28], [0, 1], {
          easing: theme.ease.inOut,
          extrapolateRight: "clamp",
        });
  const gx = prev[0] + (cur[0] - prev[0]) * t + Math.sin(frame / 90) * 3;
  const gy = prev[1] + (cur[1] - prev[1]) * t + Math.cos(frame / 110) * 3;
  return (
    <AbsoluteFill
      style={{
        background: `radial-gradient(1100px 760px at ${gx}% ${gy}%, ${withAlpha(theme.colors.accent, 0.16)} 0%, transparent 70%),
          radial-gradient(900px 600px at ${100 - gx}% ${Math.min(100, gy + 40)}%, ${withAlpha(theme.colors.primary, 0.09)} 0%, transparent 70%),
          linear-gradient(180deg, ${theme.colors.bgAlt} 0%, ${theme.colors.bg} 100%)`,
      }}
    />
  );
};

const STAR_COUNT = 46;
export const Stars: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill>
      {Array.from({ length: STAR_COUNT }).map((_, i) => {
        const x = random(`sx${i}`) * WIDTH;
        const y0 = random(`sy${i}`) * HEIGHT;
        const r = 1.2 + random(`sr${i}`) * 2.4;
        const speed = 0.12 + random(`sv${i}`) * 0.25;
        const y = (((y0 - frame * speed) % HEIGHT) + HEIGHT) % HEIGHT;
        const tw = 0.5 + 0.5 * Math.sin(frame / (18 + random(`st${i}`) * 30) + i);
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: x,
              top: y,
              width: r * 2,
              height: r * 2,
              borderRadius: "50%",
              background: theme.colors.text,
              opacity: 0.1 + tw * 0.38,
              boxShadow: `0 0 ${r * 4}px ${withAlpha(theme.colors.text, 0.5)}`,
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

export const Grade: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: `linear-gradient(180deg, ${withAlpha(theme.colors.primary, 0.05)} 0%, transparent 35%, ${withAlpha(theme.colors.bg, 0.35)} 100%)`,
      mixBlendMode: "soft-light",
    }}
  />
);

const GRAIN =
  "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='240' height='240'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 0.9 0'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>\")";
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: GRAIN,
        backgroundPosition: `${(frame * 37) % 240}px ${(frame * 53) % 240}px`,
        opacity: 0.045,
        mixBlendMode: "overlay",
      }}
    />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: `radial-gradient(ellipse at center, transparent 55%, ${withAlpha("#000000", 0.5)} 100%)`,
    }}
  />
);

/** Soft gold light sweep, centered on each scene boundary. */
export const TransitionSweep: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const len = Math.round(theme.timing.transitionSec * fps);
  const hit = SCENES.slice(1).find((s) => frame >= s.from - len / 2 && frame <= s.from + len / 2);
  if (!hit) return null;
  const p = interpolate(frame, [hit.from - len / 2, hit.from + len / 2], [0, 1], { easing: theme.ease.inOut });
  const x = -900 + p * (WIDTH + 1800);
  return (
    <AbsoluteFill style={{ pointerEvents: "none", mixBlendMode: "screen" }}>
      <div
        style={{
          position: "absolute",
          top: -200,
          bottom: -200,
          left: x,
          width: 700,
          transform: "skewX(-18deg)",
          background: `linear-gradient(90deg, transparent, ${withAlpha(theme.colors.primary, 0.22)}, ${withAlpha(theme.colors.accent, 0.12)}, transparent)`,
          filter: "blur(36px)",
        }}
      />
    </AbsoluteFill>
  );
};
