import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { theme } from "./theme";
import { SCENES } from "./timeline";
import { BgMesh, Stars, Grade, Grain, Vignette, TransitionSweep } from "./components/Layers";
import { PreviewAudio } from "./components/PreviewAudio";
import { SceneShell, Sfx } from "./components/Motion";
import { S0_Hook } from "./scenes/S0_Hook";
import { S1_AskHeart } from "./scenes/S1_AskHeart";
import { S2_BusyCards } from "./scenes/S2_BusyCards";
import { S3_NoTime } from "./scenes/S3_NoTime";
import { S4_BeforeAfter } from "./scenes/S4_BeforeAfter";
import { S5_FiveTimes } from "./scenes/S5_FiveTimes";
import { S6_Forgive } from "./scenes/S6_Forgive";
import { S7_Closing } from "./scenes/S7_Closing";
import type { SceneProps } from "./scenes/types";

const COMPONENTS: React.FC<SceneProps>[] = [S0_Hook, S1_AskHeart, S2_BusyCards, S3_NoTime, S4_BeforeAfter, S5_FiveTimes, S6_Forgive, S7_Closing];

export const Main: React.FC = () => (
  <AbsoluteFill style={{ background: theme.colors.bg }}>
    <BgMesh />
    <Stars />
    {SCENES.map((s) => {
      const Comp = COMPONENTS[s.index];
      return (
        <Sequence key={s.index} from={s.from} durationInFrames={s.duration} name={`Scene ${s.index + 1}`}>
          <SceneShell duration={s.duration} first={s.index === 0}>
            <Comp rel={s.rel} duration={s.duration} />
          </SceneShell>
        </Sequence>
      );
    })}
    <TransitionSweep />
    {SCENES.slice(1).map((s) => (
      <Sfx key={s.index} name="swipe" at={s.from - 10} />
    ))}
    <Grade />
    <Vignette />
    <Grain />
    <PreviewAudio />
  </AbsoluteFill>
);
