// theme.ts — single source of truth. No inline colors / easings / springs in components.
import { Easing } from "remotion";
import { loadFont } from "@remotion/google-fonts/HindSiliguri";

// Hind Siliguri: correct Bengali conjuncts; 700 = heaviest weight available.
const { fontFamily } = loadFont("normal", {
  weights: ["400", "500", "600", "700"],
  subsets: ["bengali", "latin"],
});

export const withAlpha = (hex: string, a: number) => {
  const h = hex.replace("#", "");
  const n = parseInt(h, 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
};

const base = {
  bg: "#0B1220",
  primary: "#E3B04B", // hero — gold, at most ONE element per frame
  accent: "#7FB7BE", // teal — secondary visuals
  text: "#F5EFE0",
};

export const theme = {
  colors: {
    ...base,
    bgAlt: "#111C31",
    textDim: "#B6B3A8",
    glow: withAlpha(base.primary, 0.4),
    glowAccent: withAlpha(base.accent, 0.35),
    surface: withAlpha(base.text, 0.06),
    surfaceStrong: withAlpha(base.text, 0.1),
    border: withAlpha(base.text, 0.16),
    borderStrong: withAlpha(base.text, 0.28),
    shadow: "rgba(0, 0, 0, 0.55)",
  },
  fonts: {
    display: `${fontFamily}, "Hind Siliguri", "Noto Sans Bengali", "Kalpurush", "Nirmala UI", sans-serif`,
    weight: { display: 700, strong: 600, body: 500 },
  },
  // Bengali needs generous line-height (tall vowel signs / ref)
  type: { lineHeight: 1.32, letterSpacing: 0 },
  radius: { card: 36, pill: 999, small: 20 },
  shadow: {
    card: "0 40px 80px -24px rgba(0,0,0,0.65), inset 0 1px 0 rgba(245,239,224,0.10)",
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  // timing in frames @30fps-independent units are derived from fps in code;
  // these are seconds.
  timing: {
    leadSec: 5 / 30, // visuals enter ~5 frames before the spoken words
    sceneInSec: 10 / 30,
    sceneOutSec: 9 / 30,
    transitionSec: 18 / 30,
  },
  // SFX gain (0.2–0.35, never covers the voiceover)
  sfx: { whoosh: 0.22, swipe: 0.26, pop: 0.28, click: 0.26, chime: 0.26, thud: 0.3 },
} as const;
