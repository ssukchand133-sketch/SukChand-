# রিজিক · মোশন গ্রাফিক্স ভিডিও (Remotion)

```
npm install
npx remotion studio
npx remotion render src/index.ts Main out/video.mp4
```

- ভয়েসওভার প্রিভিউ: `public/voiceover.mp3` রাখুন (চালু/বন্ধ: `src/config.ts`)
- রং/ফন্ট/ইজিং/স্প্রিং: `src/theme.ts`
- সময়ের সব হিসাব: `src/srt/script.ts` (SRT) → `src/timeline.ts`
- SFX আবার বানাতে: `npm run sfx`
