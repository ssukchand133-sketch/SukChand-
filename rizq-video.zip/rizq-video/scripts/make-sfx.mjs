// আধুনিক UI ধাঁচের ছোট SFX সেট সিন্থেসাইজ করে public/sfx/-এ লেখে, তারপর যাচাই করে।
// চালাতে: npm run sfx
import {mkdirSync, writeFileSync, readFileSync} from 'node:fs';
import {dirname, join} from 'node:path';
import {fileURLToPath} from 'node:url';

const SR = 44100;
const TARGET_PEAK = 0.7; // সব সাউন্ড একই peak-এ মেলানো হয়
const OUT = join(dirname(fileURLToPath(import.meta.url)), '..', 'public', 'sfx');
mkdirSync(OUT, {recursive: true});

let seed = 20261125;
const rnd = () => {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return (seed / 4294967296) * 2 - 1;
};
const make = (sec, fn) => {
  const n = Math.round(sec * SR);
  const b = new Float32Array(n);
  for (let i = 0; i < n; i++) b[i] = fn(i / SR, i);
  return b;
};
const lowpass = (b, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  for (let i = 0; i < b.length; i++) {
    y += a * (b[i] - y);
    b[i] = y;
  }
  return b;
};
const highpass = (b, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  for (let i = 0; i < b.length; i++) {
    const x = b[i];
    y += a * (x - y);
    b[i] = x - y;
  }
  return b;
};
const pad = (b, sec) => {
  const o = new Float32Array(b.length + Math.round(sec * SR));
  o.set(b);
  return o;
};
// খুব ছোট reverb: তিনটি comb, কম mix
const reverb = (b, mix) => {
  const delays = [0.0297, 0.0371, 0.0411].map((d) => Math.round(d * SR));
  const wet = new Float32Array(b.length);
  for (const d of delays) {
    const y = new Float32Array(b.length);
    for (let i = 0; i < b.length; i++) y[i] = b[i] + (i >= d ? 0.32 * y[i - d] : 0);
    for (let i = 0; i < b.length; i++) wet[i] += y[i] / delays.length;
  }
  lowpass(wet, 3000);
  const o = new Float32Array(b.length);
  for (let i = 0; i < b.length; i++) o[i] = b[i] * (1 - mix) + wet[i] * mix;
  return o;
};
const fade = (b, inMs, outMs) => {
  const ni = Math.round((inMs / 1000) * SR);
  const no = Math.round((outMs / 1000) * SR);
  for (let i = 0; i < ni && i < b.length; i++) b[i] *= i / ni;
  for (let i = 0; i < no && i < b.length; i++) b[b.length - 1 - i] *= i / no;
  return b;
};
const normalize = (b) => {
  let p = 0;
  for (const v of b) p = Math.max(p, Math.abs(v));
  const g = TARGET_PEAK / (p || 1);
  for (let i = 0; i < b.length; i++) b[i] *= g;
  return b;
};
// state-variable band-pass, সময়ের সাথে বদলানো কেন্দ্র-ফ্রিকোয়েন্সি
const sweepBand = (b, fcAt, q) => {
  let low = 0;
  let band = 0;
  for (let i = 0; i < b.length; i++) {
    const f = 2 * Math.sin((Math.PI * fcAt(i / SR)) / SR);
    const high = b[i] - low - q * band;
    band += f * high;
    low += f * band;
    b[i] = band;
  }
  return b;
};

const sounds = {
  // soft pop: দ্রুত নিচে নামা pitch সহ sine + ছোট envelope
  pop: () => {
    let ph = 0;
    const b = make(0.18, (t) => {
      ph += (2 * Math.PI * (170 + 380 * Math.exp(-t / 0.028))) / SR;
      const env = (1 - Math.exp(-t / 0.003)) * Math.exp(-t / 0.045);
      return (Math.sin(ph) + 0.16 * Math.sin(2 * ph)) * env;
    });
    return reverb(lowpass(pad(b, 0.05), 4200), 0.1);
  },
  // crisp click: high-pass করা ছোট noise burst
  click: () => {
    const b = make(0.07, (t) => rnd() * (1 - Math.exp(-t / 0.0005)) * Math.exp(-t / 0.005));
    return reverb(lowpass(highpass(pad(b, 0.03), 2200), 8000), 0.05);
  },
  // মসৃণ whoosh: band-pass noise sweep + fade in/out
  whoosh: () => {
    const dur = 0.75;
    let b = make(dur, () => rnd());
    b = sweepBand(b, (t) => 350 * Math.pow(7, t / dur), 0.9);
    for (let i = 0; i < b.length; i++) b[i] *= Math.pow(Math.sin(Math.PI * Math.min(1, i / SR / dur)), 1.6);
    return reverb(lowpass(pad(b, 0.05), 5000), 0.1);
  },
  // নরম টেক্সট swish: ছোট ও হালকা whoosh
  swish: () => {
    const dur = 0.38;
    let b = make(dur, () => rnd());
    b = sweepBand(b, (t) => 600 * Math.pow(3.2, t / dur), 1.0);
    for (let i = 0; i < b.length; i++) b[i] *= Math.pow(Math.sin(Math.PI * Math.min(1, Math.pow(i / SR / dur, 0.8))), 1.4);
    return reverb(lowpass(pad(b, 0.04), 4800), 0.08);
  },
  // chime: নরম ওভারটোনসহ ছোট decay pluck
  chime: () => {
    const partials = [
      [1, 1, 0.16],
      [2.01, 0.28, 0.09],
      [3.98, 0.08, 0.05],
    ];
    const f0 = 784;
    const b = make(0.4, (t) => {
      let s = 0;
      for (const [r, a, tau] of partials) {
        s += a * Math.exp(-t / tau) * (Math.sin(2 * Math.PI * f0 * r * t) + 0.6 * Math.sin(2 * Math.PI * f0 * r * 1.004 * t));
      }
      return s * (1 - Math.exp(-t / 0.004));
    });
    return reverb(lowpass(pad(b, 0.08), 6000), 0.14);
  },
  // খুব হালকা সফট থাড (হুকের জন্য, সংযত)
  thud: () => {
    let ph = 0;
    const n = make(0.3, () => rnd());
    lowpass(n, 220);
    const b = make(0.3, (t, i) => {
      ph += (2 * Math.PI * (52 + 48 * Math.exp(-t / 0.05))) / SR;
      return Math.sin(ph) * (1 - Math.exp(-t / 0.006)) * Math.exp(-t / 0.085) + 0.6 * n[i] * Math.exp(-t / 0.02);
    });
    return reverb(lowpass(pad(b, 0.05), 900), 0.06);
  },
};

const writeWav = (name, buf) => {
  const n = buf.length;
  const data = Buffer.alloc(44 + n * 2);
  data.write('RIFF', 0);
  data.writeUInt32LE(36 + n * 2, 4);
  data.write('WAVEfmt ', 8);
  data.writeUInt32LE(16, 16);
  data.writeUInt16LE(1, 20);
  data.writeUInt16LE(1, 22);
  data.writeUInt32LE(SR, 24);
  data.writeUInt32LE(SR * 2, 28);
  data.writeUInt16LE(2, 32);
  data.writeUInt16LE(16, 34);
  data.write('data', 36);
  data.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) data.writeInt16LE(Math.round(Math.max(-1, Math.min(1, buf[i])) * 32767), 44 + i * 2);
  writeFileSync(join(OUT, `${name}.wav`), data);
};

const maxDur = {pop: 0.5, click: 0.5, swish: 0.5, chime: 0.5, thud: 0.5, whoosh: 0.8};
let failed = false;
const report = {};
for (const [name, fn] of Object.entries(sounds)) {
  writeWav(name, fade(normalize(fn()), 1, 12));
  // লেখা ফাইল আবার পড়ে যাচাই
  const d = readFileSync(join(OUT, `${name}.wav`));
  const n = (d.length - 44) / 2;
  let peak = 0;
  let clip = 0;
  let sq = 0;
  for (let i = 0; i < n; i++) {
    const v = d.readInt16LE(44 + i * 2) / 32768;
    peak = Math.max(peak, Math.abs(v));
    if (Math.abs(v) >= 0.999) clip++;
    sq += v * v;
  }
  const dur = n / SR;
  const rms = Math.sqrt(sq / n);
  const ok = dur <= maxDur[name] && clip === 0 && Math.abs(peak - TARGET_PEAK) < 0.02;
  if (!ok) failed = true;
  report[name] = Number(dur.toFixed(3));
  console.log(`${name.padEnd(7)} dur=${dur.toFixed(3)}s peak=${peak.toFixed(3)} rms=${rms.toFixed(3)} clip=${clip} ${ok ? 'OK' : 'FAIL'}`);
}
console.log(JSON.stringify(report));
if (failed) process.exit(1);
