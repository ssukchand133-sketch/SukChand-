export type Cue = {index: number; start: number; end: number; text: string};

const toSec = (s: string): number => {
  const m = s.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) throw new Error(`SRT সময় বোঝা যায়নি: ${s}`);
  return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) + Number(m[4]) / 1000;
};

// বাংলা য়/ড়/ঢ় এর দুই ধরনের এনকোডিং মেলাতে NFC
export const norm = (s: string): string => s.normalize('NFC');

export const parseSrt = (raw: string): Cue[] =>
  raw
    .replace(/\r/g, '')
    .trim()
    .split(/\n\s*\n/)
    .map((block) => {
      const lines = block.split('\n').map((l) => l.trim());
      const [a, b] = lines[1].split('-->');
      return {
        index: Number(lines[0]),
        start: toSec(a),
        end: toSec(b),
        text: norm(lines.slice(2).join(' ')),
      };
    });
