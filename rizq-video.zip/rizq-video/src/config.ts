// ভিডিওর মূল সেটিং। সময়ের সব হিসাব SRT থেকে আসে (timeline.ts)।
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

// ভয়েসওভার প্রিভিউ: public/voiceover.mp3 থাকলে বাজবে, না থাকলে নীরবে বাদ।
export const PLAY_VOICEOVER_IN_STUDIO = true;
export const PLAY_VOICEOVER_IN_RENDER = false; // ডিফল্টে রেন্ডারে বন্ধ
export const VOICEOVER_FILE = 'voiceover.mp3';

// ভিজ্যুয়াল সংশ্লিষ্ট কথার একটু আগে ঢোকে (সেকেন্ড)
export const LEAD_S = 0.17;
// সিনের হেডিং আইটেমের আগে ঢোকার সময় (সেকেন্ড)
export const HEADING_LEAD_S = 0.35;
