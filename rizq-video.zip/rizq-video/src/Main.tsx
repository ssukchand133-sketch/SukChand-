import React from 'react';
import {AbsoluteFill, Sequence, useVideoConfig} from 'remotion';
import {scenes, SceneKey} from './timeline';
import {theme} from './theme';
import {secF} from './anim';
import {Background} from './components/Background';
import {Overlay} from './components/Overlay';
import {Sweep} from './components/Sweep';
import {SfxTrack} from './components/Sfx';
import {PreviewAudio} from './components/PreviewAudio';
import {HookScene} from './scenes/HookScene';
import {RizqScene} from './scenes/RizqScene';
import {ValueScene} from './scenes/ValueScene';
import {BodyScene} from './scenes/BodyScene';
import {GoodScene} from './scenes/GoodScene';
import {HabitScene} from './scenes/HabitScene';
import {RecapScene} from './scenes/RecapScene';
import type {SceneProps} from './scenes/types';

const COMPONENTS: Record<SceneKey, React.FC<SceneProps>> = {
  hook: HookScene,
  rizq: RizqScene,
  value: ValueScene,
  body: BodyScene,
  good: GoodScene,
  habits: HabitScene,
  recap: RecapScene,
};

export const Main: React.FC = () => {
  const {fps} = useVideoConfig();
  const overlap = secF(fps, theme.time.exit);
  return (
    <AbsoluteFill style={{backgroundColor: theme.color.bgDeep}}>
      {/* স্তর ১: ব্যাকগ্রাউন্ড মেশ */}
      <Background />
      {/* স্তর ২-৩: অ্যাসেট/গ্রাফিক্স/টাইপ (সিন) */}
      {scenes.map((s, i) => {
        const Comp = COMPONENTS[s.key];
        const ext = i + 1 < scenes.length ? s.duration + overlap : s.duration;
        return (
          <Sequence key={s.key} from={s.start} durationInFrames={ext}>
            <Comp from={s.start} duration={ext} />
          </Sequence>
        );
      })}
      {scenes.filter((s) => s.start > 0).map((s) => (
        <Sweep key={s.key} at={Math.max(0, s.start - 4)} />
      ))}
      {/* স্তর ৪-৫: কালার গ্রেড + গ্রেইন + ভিনিয়েট */}
      <Overlay />
      <SfxTrack />
      <PreviewAudio />
    </AbsoluteFill>
  );
};
