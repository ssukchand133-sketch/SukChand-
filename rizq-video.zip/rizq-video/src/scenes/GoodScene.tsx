import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, alpha} from '../theme';
import {T} from '../timeline';
import {breathe, ease, ent, enterStyle, secF} from '../anim';
import {SceneRoot} from '../components/SceneRoot';
import {Words} from '../components/Text';
import {Icon} from '../components/Icons';
import {Glass} from '../components/Glass';
import type {SceneProps} from './types';

// স্টাইল: Statement Card (মূল বার্তা)। পেছনে ধীরে ঘোরা আট-কোণা তারা (স্ট্রোক ড্র)
export const GoodScene: React.FC<SceneProps> = ({from, duration}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = T.goodTitle.map((f) => f - from);
  const card = ent(frame, fps, 0, theme.spring.soft);
  const draw = ease(frame, 2, 2 + secF(fps, 0.8), theme.ease.draw);
  return (
    <SceneRoot duration={duration}>
      <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center'}}>
        <Glass tint="none" radius={56} style={{width: 1400, height: 640, display: 'flex', alignItems: 'center', justifyContent: 'center', ...enterStyle(card, {y: 60, scale: 0.9, blur: 14})}}>
          <div style={{position: 'absolute', left: 350, top: -30, opacity: 0.5, transform: `rotate(${frame * 0.18}deg) scale(${1 + breathe(frame, fps, 4, 0.02)})`}}>
            <Icon name="star" size={700} progress={draw} color={alpha(theme.color.accent, 0.5)} stroke={0.7} />
          </div>
          <div style={{position: 'relative', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6}}>
            <Words words={[{t: 'ভালো', kind: 'grad'}, {t: 'মানুষ', kind: 'grad'}]} starts={s.slice(0, 2)} size={210} pop preset="pop" />
            <Words words={[{t: 'গড়ে'}, {t: 'তোলার'}, {t: 'সহজ'}, {t: 'উপায়', kind: 'accent'}]} starts={s.slice(2)} size={88} />
          </div>
        </Glass>
      </AbsoluteFill>
    </SceneRoot>
  );
};
