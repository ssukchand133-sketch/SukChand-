import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, alpha} from '../theme';
import {T} from '../timeline';
import {bn, breathe, ease, ent, enterStyle, secF} from '../anim';
import {SceneRoot} from '../components/SceneRoot';
import {Words, WordSpec} from '../components/Text';
import {Icon, IconName} from '../components/Icons';
import {Glass} from '../components/Glass';
import type {SceneProps} from './types';

const TILES: {label: string; sub?: string; icon: IconName; x: number; y: number; w: number; h: number; size: number}[] = [
  {label: 'পর্যাপ্ত ঘুমের অভাব', icon: 'moon', x: 760, y: 120, w: 520, h: 400, size: 56},
  {label: 'অস্বাস্থ্যকর খাদ্যাভ্যাস', sub: 'অতিরিক্ত junk food', icon: 'burger', x: 1320, y: 120, w: 480, h: 400, size: 50},
  {label: 'অতিরিক্ত মানসিক চাপ ও দুশ্চিন্তা', icon: 'scribble', x: 760, y: 560, w: 380, h: 400, size: 44},
  {label: 'অলসতা ও শারীরিক পরিশ্রমের অভাব', icon: 'dumbbell', x: 1180, y: 560, w: 620, h: 400, size: 56},
];
const TITLE: WordSpec[] = [
  {t: 'শরীর'},
  {t: 'ধ্বংস', kind: 'grad'},
  {t: 'করে'},
  {t: 'দেওয়ার'},
  {t: 'চারটি'},
  {t: 'কারণ', kind: 'accent'},
];

// ECG রেখা: প্রতি কারণে স্পন্দনের উচ্চতা কমে
const ecg = (frame: number, fps: number, amp: number, w: number): string => {
  const pts: string[] = [];
  const period = 260;
  const scroll = (frame / fps) * 150;
  for (let x = 0; x <= w; x += 4) {
    const ph = ((x + scroll) % period) / period;
    const g = (c: number, s: number) => Math.exp(-Math.pow(ph - c, 2) / s);
    const y = amp * (-1.0 * g(0.5, 0.0007) + 0.45 * g(0.56, 0.0006) - 0.25 * g(0.44, 0.0008) + 0.18 * g(0.78, 0.004));
    pts.push(`${x},${(y).toFixed(1)}`);
  }
  return 'M' + pts.join(' L');
};

// স্টাইল: Bento Grid। বাঁয়ে হেডিং + ক্ষয়িষ্ণু স্পন্দন রেখা, ডানে অসম মাপের চারটি টাইল
export const BodyScene: React.FC<SceneProps> = ({from, duration}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const st = T.body.map((f) => f - from);
  const panel = ent(frame, fps, secF(fps, 0.3), theme.spring.soft);
  const lost = st.reduce((a, s) => a + 0.2 * Math.min(1.05, ent(frame, fps, s + secF(fps, 0.15), theme.spring.gentle)), 0);
  const amp = 74 * Math.max(0.16, 1 - lost);
  return (
    <SceneRoot duration={duration}>
      <AbsoluteFill>
        <div style={{position: 'absolute', left: 120, top: 120, width: 600}}>
          <Words words={TITLE} starts={T.bodyTitle.map((f) => f - from)} size={88} justify="flex-start" maxWidth={600} />
        </div>
        <Glass style={{position: 'absolute', left: 120, top: 650, width: 580, height: 310, ...enterStyle(panel, {y: 50, scale: 0.94, blur: 10})}}>
          <svg width={580} height={310} style={{position: 'absolute', inset: 0}}>
            <path d={ecg(frame, fps, amp, 580)} transform="translate(0 155)" fill="none" stroke={theme.color.hero} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round" style={{filter: `drop-shadow(0 0 10px ${alpha(theme.color.hero, 0.7)})`}} />
            <path d="M0 155H580" stroke={theme.color.line} strokeWidth={1.5} strokeDasharray="6 10" />
          </svg>
        </Glass>
        {TILES.map((t, i) => {
          const p = ent(frame, fps, st[i], theme.spring.pop);
          const draw = ease(frame, st[i] + 4, st[i] + 4 + secF(fps, theme.time.draw), theme.ease.draw);
          const c = i % 2 ? theme.color.accent : theme.color.hero;
          return (
            <Glass key={i} tint={i % 2 ? 'accent' : 'hero'} style={{position: 'absolute', left: t.x, top: t.y, width: t.w, height: t.h, padding: 40, boxSizing: 'border-box', ...enterStyle(p, {y: 50, scale: 0.86, blur: 14})}}>
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start'}}>
                <div style={{width: 120, height: 120, borderRadius: theme.radius.icon, background: i % 2 ? theme.color.accentSoft : theme.color.heroSoft, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${1 + breathe(frame, fps, 3.3, 0.03, i)})`}}>
                  <Icon name={t.icon} size={72} progress={draw} color={c} />
                </div>
                <div style={{fontFamily: theme.font.family, fontSize: 36, fontWeight: theme.font.weight.strong, color: c}}>{bn(i + 1)}</div>
              </div>
              <div style={{position: 'absolute', left: 40, right: 40, bottom: 38, fontFamily: theme.font.family, color: theme.color.text}}>
                <div style={{fontSize: t.size, fontWeight: theme.font.weight.strong, lineHeight: 1.36}}>{t.label}</div>
                {t.sub && <div style={{fontSize: 36, fontWeight: theme.font.weight.body, color: theme.color.accent, lineHeight: 1.4}}>{t.sub}</div>}
              </div>
            </Glass>
          );
        })}
      </AbsoluteFill>
    </SceneRoot>
  );
};
