import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, alpha} from '../theme';
import {T} from '../timeline';
import {bn, breathe, clamp01, ent, enterStyle, secF} from '../anim';
import {SceneRoot} from '../components/SceneRoot';
import {RollNumber} from '../components/Text';
import {Icon, IconName} from '../components/Icons';
import {Glass} from '../components/Glass';
import type {SceneProps} from './types';

const ITEMS: {title: string; sub: string; icon: IconName}[] = [
  {title: 'সততা রাখুন', sub: 'সবসময় সত্য বলুন, কথা রাখুন', icon: 'scales'},
  {title: 'সহানুভূতিশীল হন', sub: 'অন্যের কষ্ট বুঝুন, বিপদে পাশে দাঁড়ান', icon: 'heart'},
  {title: 'রাগ নিয়ন্ত্রণ করুন', sub: 'ধৈর্য ধরুন, সহজে ক্ষমা করতে শিখুন', icon: 'wave'},
  {title: 'দায়িত্বশীল হন', sub: 'নিজের কাজ ও দায়িত্ব ঠিকভাবে পালন করুন', icon: 'flag'},
  {title: 'ভালো সঙ্গ বেছে নিন', sub: 'সৎ ও ইতিবাচক মানুষের সাথে মিশুন', icon: 'people'},
  {title: 'নিজের ভুল স্বীকার করুন', sub: 'ভুল হলে মেনে নিন এবং শুধরে নিন', icon: 'undo'},
];
const CARD_W = 700;
const CARD_H = 640;
const STEP = 360 / ITEMS.length;
const RADIUS = CARD_W / 2 / Math.tan(Math.PI / ITEMS.length);

// স্টাইল: 3D Carousel (একাধিক আইটেম, ০১… কাউন্টার)
export const HabitScene: React.FC<SceneProps> = ({from, duration}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const st = T.habits.map((f) => f - from);
  const intro = ent(frame, fps, 0, theme.spring.gentle);
  // pos: কোন কার্ড সামনে (ভগ্নাংশসহ); প্রতি আইটেমের সময়ে ১ ধাপ এগোয়
  const pos = st.slice(1).reduce((a, s) => a + ent(frame, fps, s, theme.spring.carousel), 0);
  const ringRot = -pos * STEP + (1 - Math.min(1, intro)) * -55;
  const head = ent(frame, fps, secF(fps, 0.15), theme.spring.soft);
  return (
    <SceneRoot duration={duration}>
      <AbsoluteFill>
        <div style={{position: 'absolute', top: 64, left: 0, right: 0, display: 'flex', justifyContent: 'center', ...enterStyle(head, {y: -30, scale: 0.94, blur: 8})}}>
          <Glass radius={theme.radius.pill} style={{padding: '12px 38px', fontFamily: theme.font.family, fontSize: 40, fontWeight: theme.font.weight.strong, color: theme.color.textDim, whiteSpace: 'nowrap'}}>
            <span style={{background: theme.gradient.hero, WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent', padding: '10px 0'}}>ভালো মানুষ</span> গড়ে তোলার সহজ উপায়
          </Glass>
        </div>
        <div style={{position: 'absolute', left: 0, top: 170, width: '100%', height: CARD_H, perspective: 2300, perspectiveOrigin: '50% 45%'}}>
          <div style={{position: 'absolute', left: '50%', top: 0, width: 0, height: CARD_H, transformStyle: 'preserve-3d', transform: `translateZ(${-RADIUS}px) rotateY(${ringRot}deg) scale(${0.85 + 0.15 * Math.min(1, intro)})`}}>
            {ITEMS.map((it, i) => {
              const raw = (((i - pos) * STEP) % 360 + 540) % 360 - 180;
              const near = clamp01(1 - Math.abs(raw) / STEP);
              const op = interpolate(Math.abs(raw), [0, STEP, STEP * 1.7, 180], [1, 0.5, 0, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) * clamp01(intro * (i === 0 ? 1.5 : 1));
              const draw = clamp01((near - 0.2) / 0.6);
              return (
                <div key={i} style={{position: 'absolute', left: -CARD_W / 2, top: 0, width: CARD_W, height: CARD_H, transform: `rotateY(${i * STEP}deg) translateZ(${RADIUS}px)`, opacity: op, backfaceVisibility: 'hidden'}}>
                  <Glass tint={near > 0.5 ? 'hero' : 'none'} style={{width: CARD_W, height: CARD_H, padding: 48, boxSizing: 'border-box', boxShadow: `${theme.glass.shadow}, 0 0 ${120 * near}px ${alpha(theme.color.hero, 0.34 * near)}, inset 0 1px 0 ${theme.glass.highlight}`}}>
                    <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start'}}>
                      <div style={{width: 168, height: 168, borderRadius: 52, background: theme.color.heroSoft, border: `1.5px solid ${alpha(theme.color.hero, 0.4)}`, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${1 + breathe(frame, fps, 3.4, 0.025, i)})`}}>
                        <Icon name={it.icon} size={96} progress={draw} color={theme.color.hero} stroke={3} />
                      </div>
                      <div style={{fontFamily: theme.font.family, fontSize: 46, fontWeight: theme.font.weight.strong, color: theme.color.accent}}>{bn(i + 1, 2)}</div>
                    </div>
                    <div style={{position: 'absolute', left: 48, right: 48, bottom: 52, fontFamily: theme.font.family}}>
                      <div style={{fontSize: 70, fontWeight: theme.font.weight.title, color: theme.color.text, lineHeight: 1.3}}>{it.title}</div>
                      <div style={{marginTop: 14, fontSize: 38, fontWeight: theme.font.weight.body, color: theme.color.textDim, lineHeight: 1.45, opacity: clamp01(near * 1.6), transform: `translateY(${(1 - clamp01(near * 1.6)) * 20}px)`}}>{it.sub}</div>
                    </div>
                  </Glass>
                </div>
              );
            })}
          </div>
        </div>
        <div style={{position: 'absolute', left: 150, bottom: 70, ...enterStyle(head, {x: -40, y: 0, scale: 0.94, blur: 8})}}>
          <RollNumber changes={st.slice(0, 1).concat(st.slice(1))} size={120} format={(n) => bn(n, 2)} gradient />
        </div>
        <div style={{position: 'absolute', left: 0, right: 0, bottom: 112, display: 'flex', justifyContent: 'center', gap: 16, ...enterStyle(head, {y: 30, scale: 0.9, blur: 6})}}>
          {ITEMS.map((_, i) => {
            const k = clamp01(1 - Math.abs(pos - i));
            return <div key={i} style={{height: 14, width: 14 + 52 * k, borderRadius: 14, background: k > 0.5 ? theme.color.hero : theme.color.line}} />;
          })}
        </div>
      </AbsoluteFill>
    </SceneRoot>
  );
};
