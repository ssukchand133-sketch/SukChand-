import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, alpha} from '../theme';
import {T} from '../timeline';
import {bn, breathe, ease, ent, enterStyle, secF} from '../anim';
import {SceneRoot} from '../components/SceneRoot';
import {LineMask, RollNumber} from '../components/Text';
import {Icon, IconName} from '../components/Icons';
import {Glass} from '../components/Glass';
import type {SceneProps} from './types';

const ITEMS: {label: string; icon: IconName}[] = [
  {label: 'সকালের ঘুম', icon: 'moon'},
  {label: 'নামাজে অবহেলা', icon: 'dome'},
  {label: 'কাজে অলসতা', icon: 'hourglass'},
  {label: 'ইস্তেগফারে কমতি', icon: 'beads'},
];

// স্টাইল: Glass Cards (বৈশিষ্ট্য-তালিকা) + কাউন্টার রোল
export const RizqScene: React.FC<SceneProps> = ({from, duration}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const st = T.rizq.map((f) => f - from);
  const head = ent(frame, fps, 0, theme.spring.soft);
  return (
    <SceneRoot duration={duration}>
      <AbsoluteFill>
        <div style={{position: 'absolute', left: 130, top: 190, width: 620, ...enterStyle(head, {x: -60, y: 0, scale: 0.96, blur: 10})}}>
          <div style={{display: 'flex', alignItems: 'baseline', gap: 18}}>
            <RollNumber changes={st} size={430} format={(n) => bn(n)} gradient />
            <div style={{fontFamily: theme.font.family, fontSize: 96, fontWeight: theme.font.weight.strong, color: theme.color.textFaint, lineHeight: 1.2}}>/ ৪</div>
          </div>
          <div style={{marginTop: 30}}>
            <LineMask lines={[[{t: 'রিজিক', kind: 'grad'}], [{t: 'আটকে দেয়'}]]} size={92} start={secF(fps, 0.1)} />
          </div>
        </div>
        <div style={{position: 'absolute', left: 820, top: 116, width: 980, display: 'flex', flexDirection: 'column', gap: 32}}>
          {ITEMS.map((it, i) => {
            const p = ent(frame, fps, st[i], theme.spring.pop);
            const draw = ease(frame, st[i] + 4, st[i] + 4 + secF(fps, theme.time.draw), theme.ease.draw);
            return (
              <Glass key={i} tint={i % 2 === 0 ? 'hero' : 'none'} style={{height: 188, display: 'flex', alignItems: 'center', padding: '0 44px', gap: 40, ...enterStyle(p, {x: 150, y: 0, scale: 0.94, blur: 12})}}>
                <div style={{position: 'absolute', left: 0, top: 0, bottom: 0, width: 8, background: theme.gradient.hero, transformOrigin: 'top', transform: `scaleY(${Math.min(1, p)})`}} />
                <div style={{width: 112, height: 112, borderRadius: theme.radius.icon, background: theme.color.heroSoft, border: `1.5px solid ${alpha(theme.color.hero, 0.4)}`, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${1 + breathe(frame, fps, 3.2, 0.03, i)})`}}>
                  <Icon name={it.icon} size={66} progress={draw} color={theme.color.hero} />
                </div>
                <div style={{flex: 1, fontFamily: theme.font.family, fontSize: 60, fontWeight: theme.font.weight.strong, color: theme.color.text, lineHeight: 1.35}}>{it.label}</div>
                <div style={{fontFamily: theme.font.family, fontSize: 36, fontWeight: theme.font.weight.body, color: theme.color.accent}}>{bn(i + 1, 2)}</div>
              </Glass>
            );
          })}
        </div>
      </AbsoluteFill>
    </SceneRoot>
  );
};
