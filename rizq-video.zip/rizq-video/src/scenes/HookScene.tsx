import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, alpha} from '../theme';
import {T} from '../timeline';
import {breathe, ease, ent, secF} from '../anim';
import {SceneRoot} from '../components/SceneRoot';
import {Words} from '../components/Text';
import type {SceneProps} from './types';

// স্টাইল: Kinetic Typography (হুক)। ঘোস্ট "৪" (স্ক্রিপ্টের "চারটি") + রিপল রিং।
export const HookScene: React.FC<SceneProps> = ({from, duration}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = T.hook.map((f) => f - from);
  const ghost = ent(frame, fps, 0, theme.spring.gentle);
  return (
    <SceneRoot duration={duration}>
      <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center'}}>
        {[0, 1, 2].map((i) => {
          const p = ease((frame + i * secF(fps, 0.5)) % secF(fps, 1.5), 0, secF(fps, 1.5), theme.ease.out);
          return (
            <div key={i} style={{position: 'absolute', width: 520 + p * 900, height: 520 + p * 900, borderRadius: '50%', border: `2px solid ${alpha(theme.color.hero, 0.34 * (1 - p) * ghost)}`}} />
          );
        })}
        <div
          style={{
            position: 'absolute',
            fontFamily: theme.font.family,
            fontWeight: theme.font.weight.title,
            fontSize: 1250,
            lineHeight: 1,
            color: 'transparent',
            WebkitTextStroke: `3px ${alpha(theme.color.hero, 0.26)}`,
            opacity: Math.min(1, ghost),
            transform: `scale(${0.7 + 0.3 * ghost + breathe(frame, fps, 4, 0.012)}) rotate(${breathe(frame, fps, 6, 1.6)}deg)`,
          }}
        >
          ৪
        </div>
        <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8}}>
          <Words
            words={[{t: 'চারটি', kind: 'plain'}, {t: 'জিনিস', kind: 'plain'}]}
            starts={s.slice(0, 2)}
            size={230}
            pop
            preset="pop"
          />
          <Words
            words={[{t: 'আপনার'}, {t: 'রিজিক', kind: 'grad'}, {t: 'আটকে', kind: 'mark'}, {t: 'দেয়', kind: 'mark'}]}
            starts={s.slice(2)}
            size={124}
            weight={theme.font.weight.title}
          />
        </div>
      </AbsoluteFill>
    </SceneRoot>
  );
};
