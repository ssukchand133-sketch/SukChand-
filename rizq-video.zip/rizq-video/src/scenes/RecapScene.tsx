import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, alpha} from '../theme';
import {ease, ent, enterStyle, secF, breathe} from '../anim';
import {SceneRoot} from '../components/SceneRoot';
import {Words} from '../components/Text';
import {Icon, IconName} from '../components/Icons';
import {Glass} from '../components/Glass';
import type {SceneProps} from './types';

const ITEMS: {label: string; icon: IconName}[] = [
  {label: 'সততা', icon: 'scales'},
  {label: 'সহানুভূতিশীল', icon: 'heart'},
  {label: 'রাগ নিয়ন্ত্রণ', icon: 'wave'},
  {label: 'দায়িত্বশীল', icon: 'flag'},
  {label: 'ভালো সঙ্গ', icon: 'people'},
  {label: 'ভুল স্বীকার', icon: 'undo'},
];
const TW = 520;
const TH = 290;
const GAP = 40;

// স্টাইল: Checklist Recap Grid (সমাপ্তি)। শেষ ফ্রেমেই পূর্ণ গ্রিড, এক্সিট নেই।
export const RecapScene: React.FC<SceneProps> = ({duration}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const gap = secF(fps, 0.13);
  return (
    <SceneRoot duration={duration} fadeOut={false}>
      <AbsoluteFill>
        <div style={{position: 'absolute', top: 52, left: 0, right: 0}}>
          <Words words={[{t: 'ভালো', kind: 'grad'}, {t: 'মানুষ', kind: 'grad'}]} start={0} stagger={gap} size={118} pop preset="pop" />
        </div>
        <div style={{position: 'absolute', left: (1920 - (3 * TW + 2 * GAP)) / 2, top: 290, display: 'grid', gridTemplateColumns: `repeat(3, ${TW}px)`, gap: GAP}}>
          {ITEMS.map((it, i) => {
            const s0 = secF(fps, 0.1) + i * gap;
            const p = ent(frame, fps, s0, theme.spring.pop);
            const chk = ent(frame, fps, s0 + secF(fps, 0.2), theme.spring.pop);
            const draw = ease(frame, s0 + secF(fps, 0.2), s0 + secF(fps, 0.5), theme.ease.draw);
            return (
              <Glass key={i} tint={i % 2 ? 'accent' : 'hero'} style={{width: TW, height: TH, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 22, ...enterStyle(p, {y: 50, scale: 0.88, blur: 12})}}>
                <div style={{transform: `scale(${1 + breathe(frame, fps, 3.4, 0.03, i)})`}}>
                  <Icon name={it.icon} size={92} color={i % 2 ? theme.color.accent : theme.color.hero} progress={ease(frame, s0 + 3, s0 + 3 + secF(fps, 0.4), theme.ease.draw)} />
                </div>
                <div style={{fontFamily: theme.font.family, fontSize: 52, fontWeight: theme.font.weight.title, color: theme.color.text, lineHeight: 1.35}}>{it.label}</div>
                <div style={{position: 'absolute', top: 22, right: 22, width: 64, height: 64, borderRadius: '50%', background: theme.color.hero, boxShadow: `0 0 30px ${alpha(theme.color.hero, 0.5)}`, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${Math.min(1.15, chk)})`, opacity: Math.min(1, chk)}}>
                  <Icon name="check" size={36} color={theme.color.ink} progress={draw} stroke={7} />
                </div>
              </Glass>
            );
          })}
        </div>
      </AbsoluteFill>
    </SceneRoot>
  );
};
