import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, alpha} from '../theme';
import {WIDTH, HEIGHT} from '../config';
import {T} from '../timeline';
import {bn, breathe, ease, ent, enterStyle, secF} from '../anim';
import {SceneRoot} from '../components/SceneRoot';
import {Words, WordSpec} from '../components/Text';
import {Icon, IconName} from '../components/Icons';
import {Glass} from '../components/Glass';
import type {SceneProps} from './types';

const NODES: {label: string; sub?: string; icon: IconName; x: number; y: number}[] = [
  {label: 'অতিরিক্ত সহজলভ্যতা', icon: 'door', x: 110, y: 290},
  {label: 'নিজের সীমা বা আত্মসম্মান না রাখা', icon: 'shield', x: 1210, y: 290},
  {label: 'অতিরিক্ত কথা বলা', sub: 'নিজের সব কথা বলে দেওয়া', icon: 'chat', x: 110, y: 700},
  {label: 'কথার সাথে কাজের মিল না থাকা', icon: 'mismatch', x: 1210, y: 700},
];
const NW = 600;
const NH = 200;
const HUB = {x: WIDTH / 2, y: 600, r: 150};
const TITLE: WordSpec[] = [
  {t: 'মানুষের', kind: 'plain'},
  {t: 'কাছে', kind: 'plain'},
  {t: 'মূল্য', kind: 'grad'},
  {t: 'কমে', kind: 'accent'},
  {t: 'যাওয়ার', kind: 'plain'},
  {t: 'চারটি', kind: 'plain'},
  {t: 'কারণ', kind: 'plain'},
];

// স্টাইল: Hub and Spoke। মাঝখানে "মূল্য" রিং, প্রতি কারণে ক্ষয় হয় (কোনো বানানো সংখ্যা নেই)
export const ValueScene: React.FC<SceneProps> = ({from, duration}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const st = T.value.map((f) => f - from);
  const hub = ent(frame, fps, secF(fps, 0.5), theme.spring.soft);
  // প্রতি আইটেমে রিং ২০% কমে (বাকি ২০%)
  const lost = st.reduce((a, s) => a + 0.2 * Math.min(1.05, ent(frame, fps, s + secF(fps, 0.15), theme.spring.gentle)), 0);
  const C = 2 * Math.PI * HUB.r;
  const remain = Math.max(0, 1 - lost);
  return (
    <SceneRoot duration={duration}>
      <AbsoluteFill>
        <div style={{position: 'absolute', top: 70, left: 110, right: 110}}>
          <Words words={TITLE} starts={T.valueTitle.map((f) => f - from)} size={70} maxWidth={1700} style={{margin: '0 auto'}} />
        </div>
        <svg width={WIDTH} height={HEIGHT} style={{position: 'absolute', inset: 0}}>
          {NODES.map((n, i) => {
            const toX = n.x < HUB.x ? n.x + NW : n.x;
            const d = `M${HUB.x} ${HUB.y} L${toX} ${n.y + NH / 2}`;
            const p = ease(frame, st[i], st[i] + secF(fps, 0.4), theme.ease.draw);
            return (
              <g key={i}>
                <path d={d} stroke={alpha(theme.color.hero, 0.18)} strokeWidth={2} fill="none" />
                <path d={d} stroke={i % 2 ? theme.color.accent : theme.color.hero} strokeWidth={3} strokeLinecap="round" fill="none" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p} />
              </g>
            );
          })}
        </svg>
        <div style={{position: 'absolute', left: HUB.x - 230, top: HUB.y - 230, width: 460, height: 460, ...enterStyle(hub, {y: 0, scale: 0.7, blur: 10})}}>
          <div style={{position: 'absolute', inset: 40, borderRadius: '50%', background: `radial-gradient(circle, ${theme.color.bgLift} 0%, ${theme.color.bg} 100%)`, border: `1.5px solid ${theme.glass.stroke}`, boxShadow: `0 0 ${80 + breathe(frame, fps, 3, 20)}px ${alpha(theme.color.hero, 0.3)}`}} />
          <svg width={460} height={460} style={{position: 'absolute', inset: 0, transform: 'rotate(-90deg)'}}>
            <circle cx={230} cy={230} r={HUB.r + 38} fill="none" stroke={theme.color.line} strokeWidth={18} />
            <circle cx={230} cy={230} r={HUB.r + 38} fill="none" stroke={remain > 0.5 ? theme.color.hero : theme.color.accent} strokeWidth={18} strokeLinecap="round" strokeDasharray={`${C * 1.253 * remain} ${C * 1.253}`} />
          </svg>
          <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
            <Words words={[{t: 'মূল্য', kind: 'grad'}]} size={82} start={secF(fps, 0.7)} />
          </div>
        </div>
        {NODES.map((n, i) => {
          const p = ent(frame, fps, st[i], theme.spring.pop);
          const draw = ease(frame, st[i] + 4, st[i] + 4 + secF(fps, theme.time.draw), theme.ease.draw);
          return (
            <div key={i} style={{position: 'absolute', left: n.x, top: n.y, width: NW, height: NH, ...enterStyle(p, {x: n.x < HUB.x ? -90 : 90, y: 0, scale: 0.9, blur: 12})}}>
              <Glass tint={i % 2 ? 'accent' : 'hero'} style={{width: NW, height: NH, display: 'flex', alignItems: 'center', gap: 26, padding: '0 30px'}}>
                <div style={{width: 96, height: 96, flex: '0 0 96px', borderRadius: theme.radius.icon, background: i % 2 ? theme.color.accentSoft : theme.color.heroSoft, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${1 + breathe(frame, fps, 3.4, 0.03, i)})`}}>
                  <Icon name={n.icon} size={58} progress={draw} color={i % 2 ? theme.color.accent : theme.color.hero} />
                </div>
                <div style={{flex: 1, fontFamily: theme.font.family, color: theme.color.text}}>
                  <div style={{fontSize: 42, fontWeight: theme.font.weight.strong, lineHeight: 1.36}}>{n.label}</div>
                  {n.sub && <div style={{fontSize: 30, fontWeight: theme.font.weight.body, color: theme.color.textDim, lineHeight: 1.4}}>{n.sub}</div>}
                </div>
                <div style={{alignSelf: 'flex-start', marginTop: 22, fontFamily: theme.font.family, fontSize: 34, fontWeight: theme.font.weight.strong, color: i % 2 ? theme.color.accent : theme.color.hero}}>{bn(i + 1)}</div>
              </Glass>
            </div>
          );
        })}
      </AbsoluteFill>
    </SceneRoot>
  );
};
