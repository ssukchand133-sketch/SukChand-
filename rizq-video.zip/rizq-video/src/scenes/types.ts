export type SceneProps = {from: number; duration: number};
