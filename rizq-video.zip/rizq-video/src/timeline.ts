// সব সময় SRT থেকে হিসাব করা। হাতে বসানো কোনো ফ্রেম নম্বর নেই।
// একটি cue-র ভেতরের শব্দ/আইটেমের সময় = cue-র সময়সীমায় লেখার অবস্থান অনুপাতে।
import {FPS, LEAD_S, HEADING_LEAD_S} from './config';
import {SRT} from './srt/script';
import {norm, parseSrt} from './srt/parse';

export const cues = parseSrt(SRT);
export const DURATION = Math.ceil(cues[cues.length - 1].end * FPS);

const locate = (n: number, phrase: string, from = 0) => {
  const c = cues[n - 1];
  const p = norm(phrase);
  const i = c.text.indexOf(p, from);
  if (i < 0) throw new Error(`SRT cue ${n}-এ "${phrase}" পাওয়া যায়নি`);
  return {sec: c.start + (i / c.text.length) * (c.end - c.start), next: i + p.length};
};
const toFrame = (sec: number, lead: number) => Math.max(0, Math.round((sec - lead) * FPS));

/** cue n-এ phrase যে সেকেন্ডে শুরু */
export const at = (n: number, phrase: string): number => locate(n, phrase).sec;
/** ফ্রেম (ভিজ্যুয়াল lead বাদ দিয়ে) */
export const atF = (n: number, phrase: string, lead = LEAD_S): number => toFrame(at(n, phrase), lead);
/** cue n-এ ক্রমানুসারে শব্দগুলোর ফ্রেম */
export const wordF = (n: number, words: string[], lead = LEAD_S): number[] => {
  let from = 0;
  return words.map((w) => {
    const r = locate(n, w, from);
    from = r.next;
    return toFrame(r.sec, lead);
  });
};

const starts = {
  hook: 0,
  rizq: toFrame(at(1, 'এক,'), HEADING_LEAD_S),
  value: atF(2, 'মানুষের'),
  body: atF(4, 'শরীর'),
  good: atF(7, 'ভালো মানুষ'),
  habits: atF(7, 'সততা রাখুন'),
  recap: atF(11, 'মেনে নিন'),
};

export type SceneKey = keyof typeof starts;
const order = Object.keys(starts) as SceneKey[];
export const scenes = order.map((key, i) => {
  const start = starts[key];
  const end = i + 1 < order.length ? starts[order[i + 1]] : DURATION;
  return {key, start, end, duration: end - start};
});
export const sceneOf = (key: SceneKey) => scenes.find((s) => s.key === key)!;

export const T = {
  hook: wordF(1, ['চারটি', 'জিনিস', 'আপনার', 'রিজিক', 'আটকে', 'দেয়']),
  rizq: [atF(1, 'এক,'), atF(1, 'দুই,'), atF(1, 'তিন,'), atF(2, 'চার,')],
  valueTitle: wordF(2, ['মানুষের', 'কাছে', 'মূল্য', 'কমে', 'যাওয়ার', 'চারটি', 'কারণ']),
  value: [atF(2, 'এক,'), atF(3, 'দুই,'), atF(3, 'তিন,'), atF(4, 'চার,')],
  bodyTitle: [...wordF(4, ['শরীর', 'ধ্বংস', 'করে', 'দেওয়ার']), ...wordF(5, ['চারটি', 'কারণ'])],
  body: [atF(5, 'এক,'), atF(5, 'দুই,'), atF(6, 'তিন,'), atF(6, 'চার,')],
  goodTitle: wordF(7, ['ভালো', 'মানুষ', 'গড়ে', 'তোলার', 'সহজ', 'উপায়']),
  habits: [
    atF(7, 'সততা রাখুন'),
    atF(8, 'সহানুভূতিশীল'),
    atF(8, 'রাগ নিয়ন্ত্রণ'),
    atF(9, 'দায়িত্বশীল'),
    atF(10, 'ভালো সঙ্গ'),
    atF(11, 'নিজের ভুল'),
  ],
};
