import React from 'react';
import {useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, alpha} from '../theme';
import {WIDTH, HEIGHT} from '../config';
import {ease, secF} from '../anim';

/** সিন ট্রানজিশনের হালকা আলোর রেখা (তির্যক সুইপ) */
export const Sweep: React.FC<{at: number}> = ({at}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const dur = secF(fps, 0.5);
  if (frame < at || frame > at + dur) return null;
  const p = ease(frame, at, at + dur, theme.ease.inOut);
  const x = -700 + p * (WIDTH + 1400);
  const o = Math.sin(Math.PI * p);
  return (
    <div style={{position: 'absolute', left: x, top: -200, width: 420, height: HEIGHT + 400, transform: 'rotate(14deg)', opacity: o * 0.9, background: `linear-gradient(90deg, transparent 0%, ${alpha(theme.color.hero, 0.16)} 40%, ${alpha(theme.color.accent, 0.22)} 55%, transparent 100%)`, mixBlendMode: 'screen', pointerEvents: 'none'}} />
  );
};
