import React from 'react';
import {Audio, Sequence, staticFile, useVideoConfig} from 'remotion';
import {FPS} from '../config';
import {T, scenes} from '../timeline';

// ৬টি সাউন্ডের সীমিত সেট (public/sfx/*.wav), দৈর্ঘ্য সেকেন্ডে (scripts/make-sfx.mjs-এর যাচাই করা মান)
const SFX = {
  pop: {file: 'sfx/pop.wav', len: 0.23, vol: 0.3},
  click: {file: 'sfx/click.wav', len: 0.1, vol: 0.34},
  whoosh: {file: 'sfx/whoosh.wav', len: 0.8, vol: 0.22},
  swish: {file: 'sfx/swish.wav', len: 0.42, vol: 0.2},
  chime: {file: 'sfx/chime.wav', len: 0.48, vol: 0.26},
  thud: {file: 'sfx/thud.wav', len: 0.35, vol: 0.28},
} as const;
type Name = keyof typeof SFX;
type Ev = {name: Name; frame: number};

const whooshLead = Math.round(0.14 * FPS); // whoosh-এর শিখর ট্রানজিশনের মুহূর্তে পড়ে
const sc = (k: string) => scenes.find((s) => s.key === k)!.start;

export const events: Ev[] = [
  {name: 'thud', frame: T.hook[0]},
  {name: 'swish', frame: T.hook[2]},
  ...scenes.filter((s) => s.start > 0).map((s) => ({name: 'whoosh' as Name, frame: Math.max(0, s.start - whooshLead)})),
  ...T.rizq.map((f) => ({name: 'pop' as Name, frame: f})),
  ...T.value.map((f) => ({name: 'pop' as Name, frame: f})),
  ...T.body.map((f) => ({name: 'pop' as Name, frame: f})),
  {name: 'chime', frame: T.goodTitle[1]},
  ...T.habits.map((f) => ({name: 'pop' as Name, frame: f})),
  {name: 'click', frame: sc('recap') + 8},
  {name: 'chime', frame: sc('recap') + 8 + 5 * 4},
];

export const SfxTrack: React.FC = () => {
  const {fps} = useVideoConfig();
  const seen: Record<string, number> = {};
  return (
    <>
      {events.map((e, i) => {
        const k = (seen[e.name] = (seen[e.name] ?? -1) + 1);
        const s = SFX[e.name];
        // পরপর একই সাউন্ডে সামান্য pitch ও ভলিউম ভ্যারিয়েশন
        const rate = 1 + (((k * 7) % 5) - 2) * 0.03;
        const vol = s.vol * (1 - ((k * 3) % 4) * 0.04);
        return (
          <Sequence key={i} from={e.frame} durationInFrames={Math.ceil((s.len / rate) * fps) + 2} layout="none">
            <Audio src={staticFile(s.file)} volume={vol} playbackRate={rate} />
          </Sequence>
        );
      })}
    </>
  );
};
