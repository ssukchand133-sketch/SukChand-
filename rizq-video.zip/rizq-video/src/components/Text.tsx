import React from 'react';
import {useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, alpha} from '../theme';
import {clamp01, ease, ent, enterStyle, secF} from '../anim';

// বাংলা নিয়ম: শব্দ-বিভাজন শুধু স্পেসে, কখনো অক্ষর ধরে নয়; letterSpacing 0।

export type WordKind = 'plain' | 'grad' | 'hero' | 'accent' | 'mark';
export type WordSpec = {t: string; kind?: WordKind};

export const toWords = (s: string, kinds: Record<string, WordKind> = {}): WordSpec[] =>
  s.split(' ').map((t) => ({t, kind: kinds[t] ?? 'plain'}));

/** ওয়ার্ড-বাই-ওয়ার্ড স্ট্যাগার্ড (ডিফল্ট ৪ ফ্রেম ব্যবধান), গ্রেডিয়েন্ট কীওয়ার্ড ও হাইলাইট সুইপসহ */
export const Words: React.FC<{
  words: WordSpec[];
  size: number;
  start?: number;
  starts?: number[];
  stagger?: number;
  weight?: number;
  color?: string;
  justify?: 'center' | 'flex-start';
  preset?: keyof typeof theme.spring;
  pop?: boolean;
  maxWidth?: number;
  style?: React.CSSProperties;
}> = ({words, size, start = 0, starts, stagger, weight = theme.font.weight.title, color = theme.color.text, justify = 'center', preset = 'snappy', pop = false, maxWidth, style}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const gap = stagger ?? secF(fps, theme.time.stagger);
  const pad = Math.round(size * 0.22);
  return (
    <div
      style={{
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: justify,
        columnGap: Math.round(size * 0.26),
        rowGap: Math.round(size * 0.04),
        fontFamily: theme.font.family,
        fontSize: size,
        fontWeight: weight,
        lineHeight: 1.38,
        letterSpacing: 0,
        color,
        maxWidth,
        ...style,
      }}
    >
      {words.map((w, i) => {
        const s0 = starts ? starts[i] : start + i * gap;
        const p = ent(frame, fps, s0, theme.spring[preset]);
        const sweep = ease(frame, s0 + secF(fps, 0.12), s0 + secF(fps, 0.12) + secF(fps, theme.time.draw), theme.ease.draw);
        const kind = w.kind ?? 'plain';
        const inner: React.CSSProperties =
          kind === 'grad'
            ? {
                display: 'inline-block',
                background: theme.gradient.hero,
                WebkitBackgroundClip: 'text',
                backgroundClip: 'text',
                color: 'transparent',
                padding: `${pad}px ${Math.round(pad * 0.6)}px`,
                margin: `${-pad}px ${-Math.round(pad * 0.6)}px`,
              }
            : kind === 'hero'
              ? {color: theme.color.hero}
              : kind === 'accent'
                ? {color: theme.color.accent}
                : {};
        return (
          <span
            key={i}
            style={{
              display: 'inline-block',
              whiteSpace: 'nowrap',
              position: 'relative',
              ...enterStyle(p, {y: size * 0.4, scale: pop ? 0.55 : 0.94, blur: 12}),
            }}
          >
            {kind === 'mark' && (
              <span
                style={{
                  position: 'absolute',
                  left: -size * 0.14,
                  right: -size * 0.14,
                  top: size * 0.2,
                  bottom: size * 0.06,
                  borderRadius: size * 0.16,
                  background: alpha(theme.color.accent, 0.26),
                  transformOrigin: 'left center',
                  transform: `scaleX(${clamp01(sweep)})`,
                }}
              />
            )}
            <span style={{position: 'relative', ...inner}}>{w.t}</span>
          </span>
        );
      })}
    </div>
  );
};

/** লাইন মাস্ক রিভিল: প্রতি লাইন নিচ থেকে উঠে আসে (বাংলা মাত্রা কাটা না পড়তে প্যাডিং) */
export const LineMask: React.FC<{
  lines: WordSpec[][] | string[];
  size: number;
  start?: number;
  stagger?: number;
  weight?: number;
  color?: string;
  align?: 'left' | 'center';
  style?: React.CSSProperties;
}> = ({lines, size, start = 0, stagger, weight = theme.font.weight.title, color = theme.color.text, align = 'left', style}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const gap = stagger ?? secF(fps, theme.time.stagger * 1.6);
  const padV = Math.round(size * 0.3);
  const padH = Math.round(size * 0.2);
  return (
    <div style={{fontFamily: theme.font.family, fontSize: size, fontWeight: weight, lineHeight: 1.3, letterSpacing: 0, color, textAlign: align, ...style}}>
      {lines.map((line, i) => {
        const p = ent(frame, fps, start + i * gap, theme.spring.soft);
        const parts: WordSpec[] = typeof line === 'string' ? [{t: line}] : line;
        return (
          <div key={i} style={{overflow: 'hidden', padding: `${padV}px ${padH}px`, margin: `${-padV}px ${-padH}px`}}>
            <div style={{transform: `translateY(${(1 - p) * 115}%)`, opacity: clamp01(p * 1.6), whiteSpace: 'nowrap'}}>
              {parts.map((w, j) => (
                <span
                  key={j}
                  style={
                    w.kind === 'grad'
                      ? {
                          display: 'inline-block',
                          background: theme.gradient.hero,
                          WebkitBackgroundClip: 'text',
                          backgroundClip: 'text',
                          color: 'transparent',
                          padding: `${padV}px ${padH}px`,
                          margin: `${-padV}px ${-padH}px`,
                        }
                      : w.kind === 'accent'
                        ? {color: theme.color.accent}
                        : w.kind === 'hero'
                          ? {color: theme.color.hero}
                          : undefined
                  }
                >
                  {j > 0 ? ' ' : ''}
                  {w.t}
                </span>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
};

/** কাউন্টার রোল: changes[i] ফ্রেমে মান i+1 হয়; পুরোনো সংখ্যা ওপরে যায়, নতুন নিচ থেকে ওঠে */
export const RollNumber: React.FC<{
  changes: number[];
  size: number;
  format: (n: number) => string;
  color?: string;
  gradient?: boolean;
  weight?: number;
}> = ({changes, size, format, color = theme.color.text, gradient = false, weight = theme.font.weight.title}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const n = changes.filter((c) => c <= frame).length;
  const p = n === 0 ? 1 : ease(frame, changes[n - 1], changes[n - 1] + secF(fps, theme.time.roll), theme.ease.out);
  const pad = Math.round(size * 0.3);
  const textStyle: React.CSSProperties = gradient
    ? {background: theme.gradient.hero, WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent', padding: `${pad}px`, margin: `${-pad}px`}
    : {color};
  const base: React.CSSProperties = {fontFamily: theme.font.family, fontSize: size, fontWeight: weight, lineHeight: 1.2, letterSpacing: 0, whiteSpace: 'nowrap'};
  return (
    <div style={{position: 'relative', display: 'inline-block', overflow: 'hidden', padding: `${pad}px`, margin: `${-pad}px`}}>
      <div style={{...base, visibility: 'hidden'}}>{format(n)}</div>
      {n > 1 && (
        <div style={{...base, position: 'absolute', left: pad, top: pad, transform: `translateY(${-p * 100}%)`, opacity: 1 - p}}>
          <span style={textStyle}>{format(n - 1)}</span>
        </div>
      )}
      <div style={{...base, position: 'absolute', left: pad, top: pad, transform: `translateY(${(1 - p) * 100}%)`, opacity: n === 0 ? 1 : p}}>
        <span style={textStyle}>{format(n)}</span>
      </div>
    </div>
  );
};
