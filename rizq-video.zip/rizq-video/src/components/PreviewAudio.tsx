import React, {useEffect, useState} from 'react';
import {Audio, continueRender, delayRender, getRemotionEnvironment, staticFile} from 'remotion';
import {PLAY_VOICEOVER_IN_RENDER, PLAY_VOICEOVER_IN_STUDIO, VOICEOVER_FILE} from '../config';

/** public/voiceover.mp3 থাকলে বাজবে, না থাকলে নীরবে বাদ। config.ts-এর ফ্ল্যাগে চালু/বন্ধ। */
export const PreviewAudio: React.FC = () => {
  const enabled = getRemotionEnvironment().isRendering ? PLAY_VOICEOVER_IN_RENDER : PLAY_VOICEOVER_IN_STUDIO;
  const [handle] = useState<number | null>(() => (enabled ? delayRender('voiceover-probe') : null));
  const [exists, setExists] = useState(false);

  useEffect(() => {
    if (handle === null) return;
    let cancelled = false;
    fetch(staticFile(VOICEOVER_FILE), {method: 'HEAD'})
      .then((r) => {
        const type = r.headers.get('content-type') ?? '';
        if (!cancelled && r.ok && !type.includes('text/html')) setExists(true);
      })
      .catch(() => undefined)
      .finally(() => continueRender(handle));
    return () => {
      cancelled = true;
    };
  }, [handle]);

  if (!enabled || !exists) return null;
  return <Audio src={staticFile(VOICEOVER_FILE)} />;
};
