import React from 'react';
import {AbsoluteFill, interpolate, random, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, alpha} from '../theme';
import {WIDTH, HEIGHT} from '../config';
import {scenes} from '../timeline';
import {breathe} from '../anim';

// স্তর ১: ব্যাকগ্রাউন্ড মেশ (গ্লো + ইসলামি জ্যামিতিক নকশা + ভাসমান কণা)। সারা ভিডিওতে একটানা, সিনে সিনে গ্লো সরে যায়।
const GLOW_A = [[0.25, 0.3], [0.8, 0.25], [0.2, 0.75], [0.75, 0.7], [0.5, 0.5], [0.3, 0.45], [0.5, 0.55]];
const GLOW_B = [[0.8, 0.8], [0.2, 0.7], [0.85, 0.3], [0.15, 0.25], [0.5, 0.45], [0.75, 0.6], [0.5, 0.5]];

const Particles: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return (
    <>
      {Array.from({length: 26}).map((_, i) => {
        const x = random(`px${i}`) * WIDTH;
        const speed = 8 + random(`ps${i}`) * 16;
        const y = (((random(`py${i}`) * HEIGHT - (frame / fps) * speed) % HEIGHT) + HEIGHT) % HEIGHT;
        const s = 3 + random(`pz${i}`) * 5;
        const tw = 0.25 + 0.25 * Math.sin(frame / fps * 1.4 + i);
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: x + breathe(frame, fps, 5 + (i % 4), 14, i),
              top: y,
              width: s,
              height: s,
              borderRadius: s,
              background: i % 3 === 0 ? theme.color.accent : theme.color.hero,
              opacity: tw,
            }}
          />
        );
      })}
    </>
  );
};

export const Background: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const keys = scenes.map((s) => s.start);
  const pick = (arr: number[][], axis: 0 | 1) =>
    interpolate(frame, keys, arr.slice(0, keys.length).map((a) => a[axis]), {
      easing: theme.ease.inOut,
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp',
    });
  const ax = pick(GLOW_A, 0) * WIDTH + breathe(frame, fps, 7, 40);
  const ay = pick(GLOW_A, 1) * HEIGHT + breathe(frame, fps, 9, 30, 1);
  const bx = pick(GLOW_B, 0) * WIDTH + breathe(frame, fps, 8, 40, 2);
  const by = pick(GLOW_B, 1) * HEIGHT + breathe(frame, fps, 6, 30, 3);
  const drift = (frame / fps) * 6;
  const R = 900;
  return (
    <AbsoluteFill style={{background: `radial-gradient(ellipse at 50% 40%, ${theme.color.bgLift} 0%, ${theme.color.bg} 55%, ${theme.color.bgDeep} 100%)`}}>
      <div style={{position: 'absolute', left: ax - R, top: ay - R, width: R * 2, height: R * 2, background: `radial-gradient(circle, ${alpha(theme.color.hero, 0.24)} 0%, transparent 62%)`}} />
      <div style={{position: 'absolute', left: bx - R * 0.8, top: by - R * 0.8, width: R * 1.6, height: R * 1.6, background: `radial-gradient(circle, ${alpha(theme.color.accent, 0.12)} 0%, transparent 62%)`}} />
      <svg width={WIDTH} height={HEIGHT} style={{position: 'absolute', inset: 0, opacity: 0.1, WebkitMaskImage: 'radial-gradient(ellipse at 50% 50%, black 25%, transparent 85%)', maskImage: 'radial-gradient(ellipse at 50% 50%, black 25%, transparent 85%)'}}>
        <defs>
          <pattern id="stars" width="140" height="140" patternUnits="userSpaceOnUse" patternTransform={`translate(${drift} ${drift * 0.6})`}>
            <g fill="none" stroke={theme.color.hero} strokeWidth="1.6">
              <rect x="30" y="30" width="80" height="80" />
              <rect x="30" y="30" width="80" height="80" transform="rotate(45 70 70)" />
              <circle cx="70" cy="70" r="14" />
              <path d="M0 70H30M110 70H140M70 0V30M70 110V140" />
            </g>
          </pattern>
        </defs>
        <rect width={WIDTH} height={HEIGHT} fill="url(#stars)" />
      </svg>
      <Particles />
    </AbsoluteFill>
  );
};
