import React from 'react';
import {theme} from '../theme';
import {clamp01} from '../anim';

// সব আইকন কোডে আঁকা (স্ট্রোক-স্টাইল), থিমের রঙে। ইমোজি নয়।
type Prim = {d: string} | {c: [number, number, number]};

const beads = (): Prim[] => {
  const out: Prim[] = [];
  for (let i = 0; i < 9; i++) {
    const a = Math.PI * 0.9 + (i / 8) * Math.PI * 1.2;
    out.push({c: [32 + 17 * Math.cos(a), 26 + 17 * Math.sin(a), 3.4]});
  }
  out.push({d: 'M32 43V47'}, {c: [32, 51, 3.4]}, {c: [32, 59, 2.4]});
  return out;
};

const ICONS = {
  moon: [{d: 'M44 8A24 24 0 1 0 56 42A19 19 0 0 1 44 8Z'}, {c: [50, 14, 1.6]}, {c: [56, 26, 1.6]}] as Prim[],
  dome: [{d: 'M8 54H56'}, {d: 'M14 54V38C14 26 23 20 32 13C41 20 50 26 50 38V54'}, {d: 'M32 13V6'}, {d: 'M26 54V46A6 6 0 0 1 38 46V54'}] as Prim[],
  hourglass: [{d: 'M17 8H47M17 56H47'}, {d: 'M20 8C20 26 32 28 32 32C32 36 20 38 20 56'}, {d: 'M44 8C44 26 32 28 32 32C32 36 44 38 44 56'}] as Prim[],
  beads: beads(),
  door: [{d: 'M10 56H54'}, {d: 'M18 56V10H40V56'}, {d: 'M40 12L52 17V54L40 56'}, {c: [33, 34, 1.8]}] as Prim[],
  shield: [{d: 'M32 7L52 14V31C52 44 43 52 32 58C21 52 12 44 12 31V14Z'}, {d: 'M23 32L30 39L42 25'}] as Prim[],
  chat: [{d: 'M9 12H55V43H31L18 55V43H9Z'}, {d: 'M19 23H45M19 32H36'}] as Prim[],
  mismatch: [{d: 'M12 23H52M12 40H52'}, {d: 'M27 55L38 8'}] as Prim[],
  burger: [{d: 'M9 29C9 17 19 10 32 10C45 10 55 17 55 29Z'}, {d: 'M7 37C13 41 19 33 26 37C32 41 38 33 45 37C50 40 53 38 57 37'}, {d: 'M10 45H54C54 53 50 57 44 57H20C14 57 10 53 10 45Z'}] as Prim[],
  scribble: [{d: 'M32 33C32 28 38 26 41 29C45 33 43 40 37 42C29 45 21 38 22 29C23 18 36 13 46 19C54 24 55 36 50 44'}] as Prim[],
  dumbbell: [{d: 'M7 32H57'}, {d: 'M14 20V44M22 14V50M42 14V50M50 20V44'}] as Prim[],
  scales: [{d: 'M32 9V55M17 55H47'}, {d: 'M13 19H51'}, {d: 'M13 19L7 38H23Z'}, {d: 'M51 19L45 38H59Z'}] as Prim[],
  heart: [{d: 'M32 55C10 40 7 26 15 17C22 10 30 14 32 21C34 14 42 10 49 17C57 26 54 40 32 55Z'}] as Prim[],
  wave: [{c: [32, 32, 23]}, {d: 'M15 32C20 23 26 23 32 32C38 41 44 41 49 32'}] as Prim[],
  flag: [{d: 'M15 57V9'}, {d: 'M15 11H49L42 22L49 33H15'}] as Prim[],
  people: [{c: [22, 21, 7]}, {c: [44, 24, 6]}, {d: 'M7 55C7 43 13 37 22 37C31 37 37 43 37 55'}, {d: 'M35 55C35 47 39 41 45 41C51 41 57 47 57 55'}] as Prim[],
  undo: [{d: 'M13 27A21 21 0 1 1 17 45'}, {d: 'M13 12V27H28'}] as Prim[],
  check: [{d: 'M14 33L27 46L51 18'}] as Prim[],
  star: [{d: 'M14 14H50V50H14Z'}, {d: 'M32 6L58 32L32 58L6 32Z'}] as Prim[],
};
export type IconName = keyof typeof ICONS;

/** progress: ০→১ স্ট্রোক ড্র */
export const Icon: React.FC<{name: IconName; size: number; color?: string; progress?: number; stroke?: number}> = ({
  name,
  size,
  color = theme.color.hero,
  progress = 1,
  stroke = 3.4,
}) => {
  const p = clamp01(progress);
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" style={{overflow: 'visible', opacity: p > 0 ? 1 : 0}}>
      {ICONS[name].map((pr, i) => {
        const dash = p >= 1 ? {} : {strokeDasharray: 1, strokeDashoffset: 1 - p};
        return 'd' in pr ? (
          <path key={i} d={pr.d} pathLength={1} {...dash} />
        ) : (
          <circle key={i} cx={pr.c[0]} cy={pr.c[1]} r={pr.c[2]} pathLength={1} {...dash} />
        );
      })}
    </svg>
  );
};
