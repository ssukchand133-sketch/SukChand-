import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {theme, alpha} from '../theme';

// স্তর ৪-৫: কালার গ্রেড + গ্রেইন + ভিনিয়েট (সবার ওপরে)
const noise = encodeURIComponent(
  "<svg xmlns='http://www.w3.org/2000/svg' width='256' height='256'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.6 0'/></filter><rect width='100%' height='100%' filter='url(#n)'/></svg>",
);

export const Overlay: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <>
      <AbsoluteFill style={{pointerEvents: 'none', mixBlendMode: 'soft-light', background: `linear-gradient(135deg, ${alpha(theme.color.accent, 0.22)} 0%, transparent 45%, ${alpha(theme.color.hero, 0.22)} 100%)`}} />
      <AbsoluteFill
        style={{
          pointerEvents: 'none',
          mixBlendMode: 'overlay',
          opacity: 0.1,
          backgroundImage: `url("data:image/svg+xml;utf8,${noise}")`,
          backgroundPosition: `${(frame * 53) % 256}px ${(frame * 97) % 256}px`,
        }}
      />
      <AbsoluteFill style={{pointerEvents: 'none', background: `radial-gradient(ellipse at 50% 50%, transparent 55%, ${alpha(theme.color.shadow, 0.5)} 100%)`}} />
    </>
  );
};
