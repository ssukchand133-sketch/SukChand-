import React from 'react';
import {theme, alpha} from '../theme';

/** গ্লাস কার্ড: একই কোণ, ছায়া ও বর্ডার পুরো ভিডিওতে */
export const Glass: React.FC<{
  style?: React.CSSProperties;
  tint?: 'hero' | 'accent' | 'none';
  radius?: number;
  children?: React.ReactNode;
}> = ({style, tint = 'none', radius = theme.radius.card, children}) => (
  <div
    style={{
      position: 'relative',
      borderRadius: radius,
      background:
        tint === 'none'
          ? theme.gradient.panel
          : `linear-gradient(145deg, ${alpha(tint === 'hero' ? theme.color.hero : theme.color.accent, 0.2)} 0%, ${alpha(theme.color.text, 0.04)} 100%)`,
      border: `1.5px solid ${theme.glass.stroke}`,
      boxShadow: `${theme.glass.shadow}, inset 0 1px 0 ${theme.glass.highlight}`,
      backdropFilter: `blur(${theme.glass.blur}px)`,
      overflow: 'hidden',
      ...style,
    }}
  >
    {children}
  </div>
);
