import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme} from '../theme';
import {secF} from '../anim';

/** সিনের বাইরের মোড়ক: শেষে দ্রুত (≈১০ ফ্রেম) opacity + y + scale + blur এক্সিট */
export const SceneRoot: React.FC<{duration: number; fadeOut?: boolean; children?: React.ReactNode}> = ({duration, fadeOut = true, children}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const ex = secF(fps, theme.time.exit);
  const p = fadeOut ? interpolate(frame, [duration - ex, duration], [0, 1], {easing: theme.ease.in, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : 0;
  return (
    <AbsoluteFill style={{opacity: 1 - p, transform: `translateY(${-28 * p}px) scale(${1 - 0.03 * p})`, filter: p > 0 ? `blur(${6 * p}px)` : undefined, fontFamily: theme.font.family}}>
      {children}
    </AbsoluteFill>
  );
};
