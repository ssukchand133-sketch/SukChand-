import {Easing} from 'remotion';
import {loadFont} from '@remotion/google-fonts/HindSiliguri';

// ফন্ট: Hind Siliguri (যুক্তাক্ষর ঠিক আসে)। শিরোনামে সবচেয়ে মোটা ওজন 700।
const {fontFamily} = loadFont('normal', {
  weights: ['400', '500', '600', '700'],
  subsets: ['bengali', 'latin'],
});

// কালার স্কিম ১: মিডনাইট এমারেল্ড
const base = {
  bg: '#07211C',
  bgDeep: '#041512',
  bgLift: '#0D3029',
  hero: '#1FBF8F',
  accent: '#F2C66D',
  text: '#F4F7F5',
  ink: '#07211C',
  shadow: '#000000',
};

export const alpha = (hex: string, a: number): string => {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
};

export const theme = {
  color: {
    ...base,
    textDim: alpha(base.text, 0.7),
    textFaint: alpha(base.text, 0.42),
    heroSoft: alpha(base.hero, 0.16),
    accentSoft: alpha(base.accent, 0.16),
    line: alpha(base.text, 0.14),
  },
  gradient: {
    hero: `linear-gradient(100deg, ${base.hero} 0%, ${base.accent} 100%)`,
    panel: `linear-gradient(145deg, ${alpha(base.text, 0.11)} 0%, ${alpha(base.text, 0.03)} 100%)`,
  },
  glass: {
    stroke: alpha(base.text, 0.16),
    highlight: alpha(base.text, 0.22),
    shadow: `0 34px 90px ${alpha(base.shadow, 0.38)}`,
    blur: 18,
  },
  font: {
    family: `${fontFamily}, 'Hind Siliguri', 'Noto Sans Bengali', 'Noto Sans', sans-serif`,
    weight: {title: 700, strong: 600, body: 500, light: 400},
  },
  radius: {card: 40, icon: 28, chip: 18, pill: 999},
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    in: Easing.bezier(0.5, 0, 0.9, 0.45),
    inOut: Easing.bezier(0.65, 0, 0.35, 1),
    draw: Easing.bezier(0.4, 0, 0.2, 1),
  },
  spring: {
    soft: {damping: 20, stiffness: 120, mass: 1},
    snappy: {damping: 16, stiffness: 180, mass: 0.8},
    pop: {damping: 11, stiffness: 200, mass: 0.7},
    gentle: {damping: 26, stiffness: 90, mass: 1.1},
    carousel: {damping: 22, stiffness: 70, mass: 1.2},
  },
  // সময় সেকেন্ডে; ফ্রেমে রূপান্তর fps থেকে
  time: {enter: 0.7, exit: 0.33, stagger: 0.13, draw: 0.5, roll: 0.35},
};
