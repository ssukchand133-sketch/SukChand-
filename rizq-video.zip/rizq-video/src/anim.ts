import type {CSSProperties} from 'react';
import {interpolate, spring} from 'remotion';
import {theme} from './theme';

const BN = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
export const bn = (n: number, width = 1): string =>
  String(n)
    .padStart(width, '0')
    .split('')
    .map((d) => BN[Number(d)])
    .join('');

export const clamp01 = (v: number): number => Math.min(1, Math.max(0, v));
export const secF = (fps: number, s: number): number => Math.round(s * fps);

/** স্প্রিং এন্ট্রি (০→১, সামান্য overshoot হতে পারে) */
export const ent = (
  frame: number,
  fps: number,
  start: number,
  preset: {damping: number; stiffness: number; mass: number} = theme.spring.soft,
): number => (frame < start ? 0 : spring({frame: frame - start, fps, config: preset}));

/** ইজিংসহ ০→১ */
export const ease = (
  frame: number,
  from: number,
  to: number,
  easing: (t: number) => number = theme.ease.out,
): number =>
  interpolate(frame, [from, to], [0, 1], {
    easing,
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

/** অলস এলিমেন্টের "শ্বাস" */
export const breathe = (frame: number, fps: number, period = 3.2, amp = 1, phase = 0): number =>
  Math.sin((frame / fps / period) * Math.PI * 2 + phase) * amp;

/** একসাথে opacity + translate + scale + blur */
export const enterStyle = (
  p: number,
  o: {x?: number; y?: number; scale?: number; blur?: number} = {},
): CSSProperties => {
  const {x = 0, y = 40, scale = 0.92, blur = 10} = o;
  const c = clamp01(p);
  return {
    opacity: c,
    transform: `translate(${(1 - p) * x}px, ${(1 - p) * y}px) scale(${scale + (1 - scale) * p})`,
    filter: blur ? `blur(${(1 - c) * blur}px)` : undefined,
  };
};
